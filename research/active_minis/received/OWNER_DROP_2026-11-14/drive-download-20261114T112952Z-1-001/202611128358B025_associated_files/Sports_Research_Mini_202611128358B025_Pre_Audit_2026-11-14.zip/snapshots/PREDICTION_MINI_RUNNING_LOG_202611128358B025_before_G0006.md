<!-- MINI-LOG-FORMAT: mini-log-10 -->
# Prediction Mini Running Log — 202611128358B025

> CHAT-LOCAL ACTIVE COPY — NOT A REPOSITORY FILE, NOT COMMITTED, NOT PUSHED.
> This mini is maintained in this conversation at the owner's request.
> The repository's `CURRENT_STATE.md` continues to report `Active local mini: NONE`.

## A. Authority snapshot

| Field | Value |
|---|---|
| Authority mode | `CHAT_LOCAL_ONLY`, read-only published `main` reference pinned at `008cedc4ff469e7a808292aa3667a7bffe22e273`; publication explicitly disabled by owner |
| Repository / branch / read HEAD | `danisgreat/Sports-Research` / `main` / `008cedc4ff469e7a808292aa3667a7bffe22e273` |
| Relevant working differences | `NOT_VERIFIED` — remote GitHub state was read; the owner's local working tree was not inspected or altered |
| Method / control / scoring / selection | `MDS-2026.11.11-v24.16` / `CR-2026.11.12-R1` (records status; operative control `CR-2026.11.11-R4`) / `SCV-2026.11.11-v13` / `SEL-2026.10.22-v4` |
| Prompt / mini format | `P-2026.11.11-v24.14` / `mini-log-10` |
| Active Combined Log | `prediction logs/PREDICTION_LOG_COMBINED_9.md` — repository reference only; untouched |
| Highest committed / next canonical ID | `P-638` / `P-639` — context only, no allocation |
| Reserved canonical IDs | `P-518` through `P-522` — never reuse |
| Outstanding local minis and keys | Repository active mini `NONE` per `CURRENT_STATE.md`; retired old minis archived; no chat-local event keys yet |
| MINI_KEY / first local event key | `202611128358B025` / `LOCAL-202611128358B025-G0001` |
| New canonical ID / assignment stage | `NOT_ASSIGNED` / `PROMPT_4_IMPORT` (not performed in this chat) |
| Issuing writer | `ChatGPT — this conversation only` |
| Chat-local writer session start | `2026-11-12T21:49:58+11:00` |
| Lease expiry / enforcement | `NOT_ENFORCED` — this chat-local artifact is not the repository's lease-controlled writer |
| Lease hand-overs | `NONE` |
| Frozen for settlement | `NO` |
| Reading receipt / opened at | GitHub `main` documents listed below / `2026-11-12T21:49:58+11:00` |
| Mode | `LOCAL_MINI_STAGING` — chat-local implementation, `NOT_PUBLISHED` |
| GitHub write permission | `PROHIBITED_BY_OWNER` — read-only access regardless of connected permissions |

SPORTS_ONLY / MARKET_BLIND · RESEARCH_ONLY_NOT_CERTIFIED · CANONICAL_IMPORT_STATUS: PENDING · CHAT_LOCAL_ONLY

### Reading receipt

- **Reference branch and commit:** `main` at `008cedc4ff469e7a808292aa3667a7bffe22e273` (repository read-only).
- **Current-state authority:** `CURRENT_STATE.md` (12 November 2026 records update: no active mini; each research chat gets a distinct MINI_KEY).
- **Read/reviewed:** `README.md`; `CURRENT_STATE.md`; `CORE.md`; `WORKFLOW.md` Parts A–B; `research/prompts/2_START_LOCAL_MINI.md`; `research/prompts/README.md`; `research/prompts/COMMON_OPERATING_PROTOCOL.md` (applicable sections); `CARD_AND_LOG_TEMPLATES.md` §2; `RULES_REFERENCE.md` (authority/selection index); `ACTIVE_FILE_INDEX.md` (operating index); `EXTERNAL_RESEARCH_PROTOCOL_V3.md` (current operational index).
- **Task scope:** initialize an empty local mini; no match supplied, no card, probabilities, model run, settlement, import, or published issue.
- **Allowed changes:** only this chat-local mini and its subsequent versions here.
- **Repo status:** no repository file was written, committed, pushed, or changed; local Git status was not inspected.
- **Protocol variance:** standard ENV-v2 says repository-agent operation and commit/push; the owner's explicit chat-local/no-push request overrides publication. Repository lints/freezes/leases have **not** been executed; do not claim a formally issued repository card.

## B. Local ID rules

Creating this mini consumes no canonical ID. Assign one stable `LOCAL-202611128358B025-G0001`-style key to the first **new verified event** recorded here, followed by `G0002`, and so forth. Duplicates and addenda consume no ordinal. Canonical IDs are `NOT_ASSIGNED` until a separately authorized, verified prompt-4 import during settlement; this chat-local workflow does not perform that import.

Retain full prior card text, receipts, evidence, and corrections in append-only form. Never overwrite a frozen card or import any chat-local record into the repository without a separate explicit owner authorization. All game-specific source checks, lineup research, probability calculations, timing classification, A1–A9 evidence, ranking and actual outcomes must be independently completed for each fixture.

Only this conversation is designated to update this mini; cross-conversation custody and lease enforcement are **not** available. New versions of this local file must retain the mini key and earlier content and be returned as downloadable Markdown.

## C. Carryover and evidence queue

| ID | Event key | Queue | Original card / frozen pick table | Latest revision | Open field | Responsible actor | Next source + exact field | Due (ISO, tz) | Final-time basis | Last attempt | Scheduled automation |
|---|---|---|---|---|---|---|---|---|---|---|---|
| NONE | — | — | — | — | No events to carry | — | — | — | — | — | NONE |

## D. Request intake

| Request key | Received (ISO, tz) | Event / alias as requested | Disposition | Card or addendum pointer, or no-card reason |
|---|---|---|---|---|
| SETUP-001 | 2026-11-12T21:49:58+11:00 | Activate separate chat-local mini; no match requested | SETUP_ONLY | This file initialized with zero event cards |
| SETUP-002 | 2026-11-12T22:47:58+11:00 | Re-review GitHub `main` and establish local mini accurately; no fixture | EXISTING_MINI_REVALIDATED | Audit addendum below; `MINI_KEY` and event ordinal unchanged |

| MATCH-001 | 2026-11-12T23:44:00+11:00 (user-arrival clock approx.; seconds not independently observed) | Dalibor Svrčina vs Otto Virtanen; Challenger Orléans R2; Sv +0.5, Virt −0.5, O/U 23.5; estimated Fri 13 Nov 00:00 AEDT | READ_ONLY_DRAFT | `LOCAL-202611128358B025-G0001`; research-only, start unresolved, no official issue |

| MATCH-002 | 2026-11-13T00:28:42+11:00 (save clock; original request-arrival seconds unavailable) | Torpedo Ust-Kamenogorsk vs Arlan Kokshetau, Kazakhstan Open Champs, first 12 Nov KZT fixture; Torpedo −1.5, Arlan +1.5, O/U 6.5 | READ_ONLY_DRAFT | `LOCAL-202611128358B025-G0002`; start schedule verified, exact puck drop unverified, local diagnostic; no formal issue |

| MATCH-003 | 2026-11-13T00:59+11:00 (user arrival minute; seconds unavailable) | Thiago Agustin Tirante vs Aleksandr Shevchenko, ATP Stockholm quarter-final, Friday 13 Nov 01:00 AEDT; Tirante +0.5 games, Shevchenko -0.5 games; O/U 23.5 total games | READ_ONLY_DRAFT | `LOCAL-202611128358B025-G0003`; post-scheduled-start analysis issue, actual first serve unverified, conditional scoring grid only; no formal repo issue |

| MATCH-004 | 2026-11-13T18:48+11:00 (arrival minute from message context; seconds not observed) | Geelong Venom (W) vs Perth Lynx (W), WNBL Round 5, 13 Nov 2026 19:00 AEDT; Geelong +6.5, Perth −6.5; total O/U 163.5 | READ_ONLY_DRAFT | `LOCAL-202611128358B025-G0004`; uncalibrated local conditional distribution, actual starting five/issue timing not verified, no repository issue |

| MATCH-005 | 2026-11-13T20:54+11:00 (arrival minute from message context; seconds unverified) | Wonju DB Promy v Suwon KT Sonicboom, KBL, 13 Nov 2026 21:00 AEDT; Promy −5.5, Sonicboom +5.5; O/U 179.5 points | READ_ONLY_DRAFT | `LOCAL-202611128358B025-G0005`; uncalibrated normal diagnostic, no formal model freeze or canonical issue |

## E. Model execution manifest

`NOT_APPLICABLE_AT_MINI_CREATION`. Current MINI-v2 instructions explicitly specify **no companion execution-manifest file** for new mini-log-10 records. Each future event must state its actual reference/model run and freeze disposition; no model execution is implied by setup.

## Setup audit addendum — 2026-11-12T22:47:58+11:00

**Disposition:** `ALREADY_EXISTS / REVALIDATED`, no new mini namespace, no local event ordinal consumed, no P-ID allocated. This is a setup/audit record, not an event card.

### Current GitHub authority and input custody

| Control | Checked status |
|---|---|
| Repository/branch | `danisgreat/Sports-Research` / `main`; **READ ONLY** |
| Exact main commit checked | `008cedc4ff469e7a808292aa3667a7bffe22e273` |
| `CURRENT_STATE.md` (12 Nov 2026) | Repository active local mini: `NONE`; each research chat keeps a distinct `MINI_KEY` |
| Current method/prompt/scoring/selection | `MDS-2026.11.11-v24.16` / `P-2026.11.11-v24.14` / `SCV-2026.11.11-v13` / `SEL-2026.10.22-v4` |
| Mini procedure | `MINI-v2`; format `mini-log-10`; unique `LOCAL-<MINI_KEY>-G####` identity |
| Canonical context only | Highest `P-638`, next `P-639`; `P-518`–`P-522` reserved; **none assigned or reserved here** |
| Archive namespace check | No file with this `MINI_KEY` among the retired active minis; GitHub code search also returned no match |
| Current active shared log | `prediction logs/PREDICTION_LOG_COMBINED_9.md`; no edits |
| Local original / SHA-256 | Initial local mini `PREDICTION_MINI_RUNNING_LOG_202611128358B025.md`, `10f146897ae7c87f02b36dcb35504bb754ba724277c83e224a992e576673da80`; byte-for-byte snapshot retained separately |
| New chat-local working path | `research/active_minis/202611128358B025.md` **inside the ChatGPT sandbox only**, not in the owner's Git clone |
| Chat-local operator | This conversation; simultaneous writers or lease expiry cannot be enforced across other chats |
| External research routing | `EXT-v3`: external chats act as research lanes; they are not repository-authorised issuers of official game cards |
| Repository control verification | The **remote** pinned commit was read; the owner's physical local clone/dirty files/lease locks were not inspected |

### Compliance and scope gates

- **PASS — identity/format:** same unique mini key and `mini-log-10` marker; first/next local event is `LOCAL-202611128358B025-G0001`, with last local event `NONE`.
- **PASS — empty mini:** zero game cards, zero forecast/qualitative/NO_FORECAST rows, zero pending event or unresolved evidence records; there are no invented fixtures, reference values, player details, source checks or probabilities.
- **PASS — intake preservation:** setup requests are retained as metadata, not represented as sports events. Existing initial mini snapshot is preserved.
- **PASS — canonical restraint:** no `P-###` issued or reserved, no settlement or prompt-4 import; remote next-ID snapshot is informational only.
- **PASS — execution restraint:** no model reference run, numerical simulation, training, freeze, lint, learning log or official issued card is claimed; mini-log-10 has **no ML_EXECUTION_MANIFEST.csv companion** (section E above is legacy explanatory text, not a manifest).
- **PASS — publication prohibition:** no GitHub create/edit/commit/push/branch/API mutation was performed. `CURRENT_STATE.md` in GitHub continues to say active mini `NONE`.
- **SCOPE LIMITATION — repository workflow:** repository `ENV-v2` normally requires its own working tree, a verified single writer and lease, `CURRENT_STATE.md` pointer update, repository lints/freeze receipts and commit/push; these were intentionally **NOT_PERFORMED** because the owner ordered chat-local changes with no GitHub updates. This artifact is **CHAT_LOCAL_DRAFT / NOT_REPOSITORY_ISSUED**.
- **NEXT EVENT PROCEDURE:** research under `CORE.md`, `research/prompts/1_GAME_CARD.md`, the exact sport file, `RESEARCH_PROTOCOL.md`, `ROSTER_AVAILABILITY_PROTOCOL.md`, `HISTORICAL_SOURCE_PROTOCOL.md` and source-access rules; record exact supplied contracts, timing, A1–A9, source clocks and honest missingness. Append a locally labeled research draft/addendum and update intake/footer/readback. Do not claim repository issuance or model freeze absent actual evidence.

**Status after audit:** `ACTIVE_CHAT_LOCAL`; `NOT_PUBLISHED`; `NOT_IMPORTED`; **zero fixture requests**. All GitHub operations were read only.

# NEW LOCAL EVENT CARDS

<!-- BEGIN CHAT_LOCAL_DRAFT LOCAL-202611128358B025-G0001 -->
## Research card G0001 — Svrčina vs Virtanen, Orléans 2026

**Classification:** `CHAT_LOCAL_RESEARCH_DRAFT`; `RESEARCH_COMPLETION: INFORMATION_INCOMPLETE`; `REPOSITORY_CARD_ISSUED: NO`; `CANONICAL_ID: NOT_ASSIGNED`; `FREEZE_RECEIPT: NONE`; `SETTLEMENT: NOT_PERFORMED`; `MODEL_STATUS: LOCAL_UNCALIBRATED_DIAGNOSTIC_ONLY`. This is not a repository-issued `BEGIN CARD` core or a prospective certified forecast. **Do not relabel this research as a clean pre-start-issued probability.**

### A1. Authority, exact request and identity

| Field | Recorded value |
|---|---|
| Local event key | `LOCAL-202611128358B025-G0001` — immutable |
| Intake / analysis completion | Owner request received 2026-11-12 23:44 AEDT (user message arrival context); research read and local write 2026-11-12T23:57:37+11:00 (AEDT); source retrievals between approximately 23:44 and 2026-11-12T23:57:37+11:00 AEDT |
| Repository authority | Pinned read-only `main` SHA `008cedc4ff469e7a808292aa3667a7bffe22e273`; `MDS-2026.11.11-v24.16`; `P-2026.11.11-v24.14`; `SCV-2026.11.11-v13`; `SEL-2026.10.22-v4` |
| Tournament / draw | Co'met Orléans Open, ATP Challenger 125, 9–15 November 2026; Round 2 / R16; singles; Central Arena, Orléans, France; indoor hard court; best of three sets |
| Players | Dalibor Svrčina (CZE) vs Otto Virtanen (FIN), name accents normalised; tournament 2026 exact identity verified |
| Requested estimated start | Friday 13 November 2026 00:00 AEDT = Thursday 12 November 2026 13:00 UTC = 14:00 CET |
| Conflicting scheduled feeds | TennisPadelScore 13:00 UTC; Sofascore/TennisTemple 12:30 UTC; Flashscore/other feeds 10:00 UTC; Tennisora 18:30 UTC. Official Thursday order-of-play PDF / actual first serve not retrieved. `SCHEDULE_CONFLICT`; `ACTUAL_FIRST_PLAY: NOT_VERIFIED` |
| Issue phase/exposure | Research happened near or potentially after earlier listed starts, while before the owner's estimate. `PRE_START_ISSUE: NOT_VERIFIED`; match result was **not consulted or used**. No assumed kickoff/issue timestamp or freeze claim |
| Supplied contract 1 | Svrčina **+0.5 games**, full completed match games margin; wins when Svrčina games ≥ Virtanen games |
| Supplied contract 2 | Virtanen **−0.5 games**, inverse on full completed match games margin; wins when Virtanen games ≥ Svrčina games + 1 |
| Supplied contract 3 | **Over 23.5** total games in completed match, including all played deciding-set games |
| Supplied contract 4 | **Under 23.5** total games in completed match |
| H2H | No previous meeting identified in available H2H listings. `n=0` |
| Tournament withdrawals | The main draw lists G. Mpetshi Perricard (knee), D. Lajović (neck); **not the two participants**; do not conflate with a participant injury |

### A2. Fixture/state check and scope

- **Official identity:** ATP tournament overview and official ATP Challenger draw corroborate the exact R16 matchup. First-round results are final before this request, but official Nov 12 order-of-play and real-time state remained unavailable/conflicted.
- **Source timing:** Site publication/refresh clocks are distinct from this research read time; items without authentic published-at receipts are `KNOWN_AT_UNVERIFIED`. Current page caching and the possible 12:30 UTC start prohibit a verified prospective issuance label.
- **No duplicate:** Mini contained zero game cards before this append; exact fixture keys/aliases not previously present in this chat-local mini. Formal canonical duplicate scan of full repository Combined Log and owner's physical working copy `NOT_EXECUTED`.
- **Terms:** Half-game lines cannot push in completed matches. Retirement, walkover and abandoned-match operator settlement rules were not supplied; probabilities below are `COMPLETED_MATCH_CONDITIONAL`, not assumptions that an operator would grade all cases identically.

### A3. Evidence, form, health, opponent adjustment and conditions

**Confirmed 2026 Orléans R1 (10 Nov):**
- Svrčina d. Vitaliy Sachko 2–6, 6–3, 7–6(6), **30 total games** and one tiebreak; recovered from losing the first set.
- Virtanen d. Dino Prižmić 6–1, 2–6, 7–6(2), **28 total games** and one tiebreak; recovered from losing the second set.

**Source-reconstructed recent completed singles matches (scores before this event; W/L for the named player):**

| Window | Svrčina W–L | Svrčina 3-set / Over 23.5 / mean games | Virtanen W–L | Virtanen 3-set / Over 23.5 / mean games | Reliability |
|---|---|---|---|---|---|
| L5 | **4–1** | **5/5 · 5/5 · 28.6** | **3–2** | **2/5 · 2/5 · 23.2** | Dated score lines reconstructed |
| L10 | **8–2** | **9/10 · 9/10 · 27.8** | **6–4** | **3/10 · 4/10 · 23.9** | Completed matches only, excluding Sv's 6 Oct retirement |
| L15 | **11–4** | **9/15 · 11/15 · 28.5** | **10–5** | **5/15 · 8/15 · 26.3** | Includes two Svrčina and one Virtanen best-of-five Grand Slam match; **NOT a like-for-like BO3 rate** |
| L20 | `NOT_VERIFIED` | insufficient confidently normalised completed-match score rows | `NOT_VERIFIED` | insufficient confidently normalised completed-match score rows | Source escalation required; no invented n=20 |

**Exact L10 result chain:**
- Svrčina: W Sachko (30g); L Rodionov (30); W Piros (26); W Mpetshi Perricard (33); W Gombos (24); L Medvedev (17); W Etcheverry (30); W Norrie (28); W Harris (35); W Sharipov (25). His recent completed three-set share is unusually high, so simply projecting 9/10 deciding sets is inappropriate; opponents differ greatly.
- Virtanen: W Prižmić (28g); L Djere (29); W Sachko (21); L Kouamé (15); W Travaglia (23); W Bobichon (23); W Martineau (23); L Sachko (20); L Stricker (33); W Bertola (24). Three consecutive Brest wins featured a 7–6 opening set; he was comprehensively beaten by Kouamé in its semifinal.

**2026 same-site/surface records:** Tennis Explorer listed indoor Svrčina **4–1** and Virtanen **9–5** at its last checked snapshot; class/surface splits are small and not equally sample-complete. Other site season/match ledgers may treat indoor as a separate category from outdoor hard, and their ranking snapshots differ; these definitions are not silently combined.

**Style and direct matchup:** Svrčina is return-oriented, more consistent recently and has the stronger opponent-adjusted hard-court Elo in the most recently indexed Tennis Abstract excerpt. Virtanen is a taller, more serve-reliant indoor specialist whose hard first serve increases short-point and tiebreak possibilities. Shared opponent Sachko: Virtanen beat him 6–3, 7–5 at Bratislava 4 Nov; Svrčina beat him in three sets at Orléans 10 Nov, an uncontrolled comparison (different dates/conditions). The two men have no established direct H2H edge.

**Elo status:** A recently indexed Tennis Abstract listing displayed Svrčina overall **1717.3**, hard Elo **1699.2**, and Virtanen overall **1637.5**, hard Elo **1598.9**; 50:50 overall/hard blend 1708.25 versus 1618.20, gap +90.05 and implied best-of-three Svrčina winner 1/(1+10^(−90.05/400)) = **0.6268**. **Provenance conflict:** opening the source returned an older 3 Aug 2026 version; this newer search excerpt's exact update clock could not be directly verified. Therefore this is a **context-only / NOT_FROZEN_ELO_BENCHMARK**, not an admitted current reference or an official match-winner probability. Elo also does not directly price total games/half-game spreads.

**52-week observed serve/return stats, from Tennis Foresight indexed player comparison:** Svrčina 59.2% service points won, 43.8% return points won; Virtanen 66.2% service points won, 35.6% return points won; observations cover 64 and 63 matches with statistics, respectively, across surfaces. This is not a verified indoor-only feed. Serve-return sample sizes are larger than each player's indoor subsample; selection of an exact indoor adjustment is **UNRESOLVED**.

**Fitness/availability:** Both completed their 10 Nov matches. No official same-day medical/retirement or suspension notice for either was verified. This means **FITNESS_UNCONFIRMED**, not healthy/fully fit confirmed. Svrčina played four consecutive three-set matches in Bratislava during 3–7 Nov plus another on 10 Nov; Virtanen played at Brest 26–31 Oct, Bratislava 4–5 Nov, and a three-set R1 on 10 Nov. Both had approximately one full calendar day off between rounds. The match is indoor, so external weather is not a material score input. Ball speed/court-pace data, player pressers and any last-minute changes were not independently established.

### A4. Numerical research (independently executed local scenario, **NOT** registered primary)

**Model role and limitations:** `LOCAL_TENNIS_POINT_CHAIN_SCENARIO` only. Executed in the ChatGPT sandbox with CPython on dated pre-event player-stat inputs. This is an original, explicitly uncalibrated arithmetic exercise; it is **not** the repository's `ANALYST_PRIMARY_V1`, its kit, an accepted source-audited packet, a frozen model, a shadow on the repository's execution ledger, or a certified pre-start prediction. No claims of 100,000 Monte Carlo iterations, fitted form-shock, regression calibration or exact independent Elo-to-point mapping.

**Inputs, recipe and reproduction:** Use the above raw serve/return percentages to make symmetric two-view service-point proxies:
- `p(Svrčina wins a point on own serve) = [0.592 + (1 − 0.356)]/2 = 0.618`.
- `p(Virtanen wins a point on own serve) = [0.662 + (1 − 0.438)]/2 = 0.612`.
- Each service game: exact first-to-four, win-by-two i.i.d. point recursion, with deuce tail `p²/(p²+(1−p)²)`; first server equally likely. Each set: alternating game service, first to six by two, tiebreak at 6–6; seven-point, win-by-two tiebreak with official serving rotation and exact deuce continuation. Best of three; carry serve rotation between sets; enumerate all winner/loss, set-score and total-games states. Independent points and fixed serve-point rates **omit latent form covariance, game-to-game shocks, match fitness changes and condition-specific tilt**.
- Local reproducible script: `/mnt/data/tennis_scenario_20261112.py`, SHA-256 `450f2fa1e0618f84035b4e83105412e142991afe91c02abaa4caafdaa4c7860e`. `N/A` random seed or Monte Carlo error: **deterministic recursion**, not simulation; total probability sum numerically 1.000000 within floating point.

| Quantity / exact supplied contract | Local diagnostic conditional probability | Complement / note |
|---|---:|---|
| Svrčina +0.5 full-match games | **55.4476%** | Virtanen −0.5 = **44.5524%** |
| Virtanen −0.5 full-match games | **44.5524%** | Svrčina +0.5 = **55.4476%** |
| Over 23.5 completed-match games | **53.6635%** | Under 23.5 = **46.3365%** |
| Under 23.5 completed-match games | **46.3365%** | Over 23.5 = **53.6635%** |
| Svrčina match winner (not requested) | **53.0549%** | Not a substitute for games handicap |
| Deciding third set (not requested) | **49.9170%** | Historical samples differ substantially |

**Moments from same enumerated grid:** E[Svrčina games] **12.74**; E[Virtanen games] **12.43**; E[total] **25.17**; E[Svrčina−Virtanen games] **+0.31**. Probability mass normalization **1.000000000000**. All four supplied half-line contracts have zero push probability in completed matches. Not quantified: injury-driven voids/retirement handling; no confident player-specific form-shock sigma.

**Uncertainty / scenario sensitivity, not predictive intervals:**
- Opponent/condition tilt toward Virtanen: Svr service-point win 0.608; Virtanen 0.622 → Svr +0.5 **45.1%**, Over 23.5 **53.3%**.
- Raw all-surface two-view base: 0.618 / 0.612 → Svr +0.5 **55.4%**, Over 23.5 **53.7%**.
- Opponent/condition tilt toward Svrčina: 0.628 / 0.602 → Svr +0.5 **65.4%**, Over 23.5 **52.1%**.
- High-serve setting proxy: 0.640 / 0.6335 → Svr +0.5 **55.8%**, Over 23.5 **54.8%**.
These are deliberate ±1 percentage-point proxy sweeps, **not measured likelihood distributions or confidence intervals**. They show that a small service-point advantage change can invert the games-handicap selection; the total-games direction is more stable but only marginally above 50%.

**Frozen reference/league comparator/ML:** `REFERENCE_TIER: TENNIS C (repo rules, not executed by repository command)`; `REPOSITORY_REFERENCE_RUN: NOT_RUN_LOCAL_REPO_UNAVAILABLE`; `BASELINE_LEAGUE_V1: NOT_COMPUTED (no verified comparable pre-start all-Challenger BO3 exact-line cohort)`; `MODEL_P: NONE`; `p_card: NOT_ISSUED`; `CARD_FREEZE: NOT_PERFORMED`; `ELO_CONTEXT: NOT_FROZEN`; no ledger/ML rows imported. The scenario's numerical probabilities **must not be mistaken for qualified p_card**.

### A5. Selection, dependence, abstention

**Diagnostic-only ordering (not formal PICKS_V2 issued ranks):** (1) Svrčina +0.5 game, **55.4%**; (2) Over 23.5, **53.7%**; (3) Under 23.5, **46.3%**; (4) Virtanen −0.5, **44.6%**, sorted by the one local recursion. This is a weak ordering, not a safe bet. User's preferred single **directional lean: Svrčina +0.5**, but **ABSTAIN_RECOMMENDED: YES** because of stale/conflicted Elo, indoor-data scarcity, official-start uncertainty and wide service advantage sensitivity.

**Relative robustness note:** Over 23.5 remains about 52–55% in the stated point-rate scenarios and is a lower-confidence alternative; 9/10 recent Svrčina completed matches exceeded 23.5 but only 4/10 Virtanen matches did. Do not extrapolate player history as the identical-opponent head-to-head distribution. Margin and total are correlated through match length; **no independent joint probability published** and the opposite sides of each same half-line are exact complements. Under 23.5 is feasible in two efficient straight sets; a third set usually wins the Over unless unusually short games sets occur.

### A6. Format, rules, execution and event-time gates

- Challenger singles best of three regular sets, advantage service games and 7-point tie-break at 6–6 in each set (subject to official event exception verification). Each tie-break set counts 13 games, not its points. No match tie-break substitution assumed.
- All calculations apply to completed match. Event-specific retirement/operator settlement rule `UNKNOWN_DEFINITION`; no synthetic void/graded result.
- Venue Central Arena indoor hard, CET (UTC+1); 13:00 UTC = 14:00 CET = 00:00 AEDT on Friday Nov 13. Other schedule feeds have 12:30 UTC (23:30 AEDT) and 10:00 UTC (21:00 AEDT); actual start unverified. This research cannot be certified as a pre-start issue on those records.
- No odds, tips, bookmaker prices, market references, model forecasts from third parties or in-play states were admitted to the numerical calculation.

### A7. Locally retained decision and integrity

- **Owner-facing single lean (if forced):** Svrčina +0.5 games; **low confidence / abstain advised**. Over 23.5 marginal secondary directional lean. No independently validated high-confidence contract.
- **Research-only rank, not official issuance:** The source arrays and deterministic code were preserved at the listed local paths. Do not promote this card to the repository Combined Log or score it as a prospective frozen model forecast.
- **Known-at:** All match scores/observations used are for prior completed matches dated no later than 10 Nov 2026. Some public source versions and page update timestamps are not audit-grade; clean pre-start issue is **NOT_VERIFIED**. The requested Svrčina–Virtanen outcome was not used or settled.
- **Write disposition:** `READ_ONLY_DRAFT / LOCAL_MINI_G0001`; no P-ID, no source receipt hash produced by repository kit, no official freeze, no git writes, no imported results.

### A8. Source and field-attempt ledger (all open/read unless noted)

| Source (URL) | Used field / recorded finding | Source publication & actual read / disposition |
|---|---|---|
| https://www.atptour.com/en/tournaments/-/2273/overview | Official Orleans 2026 Challenger event 9–15 Nov | Page update time unknown; read 12 Nov 2026 AEDT evening |
| https://www.protennislive.com/posting/2026/2273/mds.pdf | Official draw contains Svrčina vs Virtanen R16; list includes other players' injuries | Search extraction returned; direct PDF open failed; **PDF image/date not independently inspected**; no invented order of play |
| https://www.sofascore.com/tennis/match/dalibor-svrcina-otto-virtanen/tJQbsxcec | Exact venue/surface and 12:30 UTC schedule | Provider start differs from other feeds, no confirmed first serve |
| https://tennispadelscore.com/tournaments/orleans-challenger-2026/ | R16 and 13:00 UTC listing | Site says updated 12 Nov 00:17 UTC; current live state not verified |
| https://www.onlajny.com/match/index/date/2026-11-12/id/555504 | 14:00 CET, first meeting/pre-match preview | Indexed no-live-score page only; publication 12 Nov, exact capture time unknown |
| https://en.tennistemple.com/player/dalibor-svrcina/results | Svrčina pre-event dated match-score list, first-round victory, Oct/Nov matches | Indexed data checked 12 Nov 2026, time undetermined; differences with other provider inspected |
| https://en.tennistemple.com/player/otto-virtanen/results | Virtanen pre-event dated match-score list, 10 Nov tiebreak win, Brest sequence | Indexed data checked 12 Nov 2026, time undetermined |
| https://en.24score.com/tennis/player/czech_republic/svrcina_dalibor/ | Svrčina dated-score cross-check | Direct open cache miss; indexed page supplied score lines |
| https://en.24score.com/tennis/player/finland/virtanen_otto/ | Virtanen dated-score cross-check | Direct open cache miss; indexed page supplied score lines |
| https://www.tennisexplorer.com/match-detail/?id=3376021 | Player 2026 indoor W–L at small n, approximate ranking | Retrieved search excerpt but direct open cache miss |
| https://tennisforesight.com/match/12178892-svrcina-vs-virtanen-orleans | Raw last-52-week point and game statistics with observed sample counts, match record and H2H status; **its site's forecast was not read or used** | Indexed stats timestamp not independently published; cannot claim certification under repo source-audit rules |
| https://tennisabstract.com/reports/atp_elo_ratings.html | Elo recent search snippet context | Source cache inconsistent (indexed fresh excerpt vs direct Aug 2026 page); NOT_FROZEN |
| https://opendorleans.com/wp-content/uploads/2026/11/OP11.11.pdf | Wednesday 11 Nov official OOP exists | Not an authoritative Thursday start; direct opening failed |
| Official Thursday 12 Nov order of play | Exact match order, confirmed local start/first service | `NOT_VERIFIED`: searches / guessed official URLs failed; verify externally before claiming prospective timing |
| Official player fitness / injury notices | Explicit clearance/medical absence for both players | `NOT_VERIFIED`: no positive evidence after search; do not infer fitness |
| Local repo source-audit/kit/registry | CLAUDE_AGENT reader permission, reviewed collector access, kit receipts, actual model release | `NOT_EXECUTED`: user's GitHub repo was read remotely only; no approved local worker checkout or permission audit available; cannot certify access or generated numeric artifacts as repository originals |

### A9. Seven-step completion matrix and open actions

| Procedure | State / observed reason | Next exact requirement |
|---|---|---|
| 1 Authority | `REVIEWED_REMOTE_PIN`, owner no-push overrides repository writer | Repository working-copy/dirty tree/lease unavailable, official issue disallowed |
| 2 Exact identity / timing / duplicates | `IDENTITY_VERIFIED`; `TIMING_UNVERIFIED`; local mini checked empty | Official 12 Nov OOP and provable first service; canonical duplicate scan required for official import |
| 3 Evidence / roster / historical | `PARTIAL`: both L5/L10/L15 with source scores, no verified L20; no participant injury notice | Complete L20 BO3-normalised windows, serving/return indoor source with declared grain, official status/withdrawal recheck |
| 4 Distribution / baseline | `LOCAL_SCENARIO_EXECUTED`, sum=1; local source data not source-audited; baseline/freeze absent | Repo-compatible point-to-match toolkit and documented player-specific form sigma; competition baseline |
| 5 Selection / dependence | `DIAGNOSTIC_RANKED / ABSTAIN`, four supplied sides; joint dependence not claimed | Valid frozen analyst reference and PICKS_V2 linter for formal issuance |
| 6 Venue / rules / settlement | `CONDITIONAL_COMPLETED`, indoor, BO3; tiebreak exact-event not separately confirmed | Verify official set and betting-operator retirement rule if settlement requested |
| 7 Write / audit / return | `CHAT_LOCAL_APPEND`, append readback required, no GitHub | Recheck this file, intake/footer/key continuity, hashes and user delivery |

**Due/recheck status:** No automation actually scheduled; `AUTOMATION: NONE`. Official timing/medical sources and actual match state must be checked manually if the owner later requests an updated status, without rewriting the original dated research. **Research completeness:** `INFORMATION_INCOMPLETE` (specific gaps above), numeric shadow `EXECUTED_LOCAL_SCENARIO`, official issuance `NOT_PERFORMED`, official settlement `NOT_PERFORMED`.
<!-- END CHAT_LOCAL_DRAFT LOCAL-202611128358B025-G0001 -->

<!-- BEGIN CHAT_LOCAL_DRAFT LOCAL-202611128358B025-G0002 -->
## Research-only event LOCAL-202611128358B025-G0002: Torpedo Ust-Kamenogorsk vs Arlan Kokshetau

**Classification:** CHAT_LOCAL_RESEARCH_DRAFT / NO_REPOSITORY_ISSUANCE / CUSTODY_UNCERTIFIED / NOT_CALIBRATED / SPORTS_ONLY / MARKET_BLIND.  This card is not a repository-issued PREDICTION, signed pre-match receipt, officially frozen pregame forecast, or valid prospective scoring entry.  Numeric values are transparent **conditional scenario diagnostics** computed locally with independent Poisson count scores and an explicit one-goal OT/SO tie adjustment, not the validated hockey simulator and not the repository `ANALYST_PRIMARY_V1` freeze. `CANONICAL_ID: NOT_ASSIGNED`.

### A1 — Identity and event endpoint

| Field | Value |
|---|---|
| Requested match | Torpedo Ust-Kamenogorsk (home) vs Arlan Kokshetau (away), Kazakhstan Open Champs / Kazakhstan Pro Hokei Ligasy 2026/27 |
| Native league fixture | League schedule row **131**, **12 Nov 2026 18:30** Kazakhstan/Astana time (UTC+05:00), `2026-11-12T13:30:00Z` / `2026-11-13T00:30:00+11:00` Melbourne |
| Opposite adjacent fixture | League schedule row **133**, **13 Nov 2026 18:30** Kazakhstan time: **different second game; excluded** |
| Venue | Boris Alexandrov Sports Palace, Oskemen (Ust-Kamenogorsk), Kazakhstan |
| User contracts | Torpedo −1.5 goals; Arlan +1.5 goals; Over 6.5; Under 6.5 |
| Default endpoint | Full-game final scoreboard **including overtime/shootout** subject to operator rule `UNKNOWN_DEFINITION`; also calculate 60-minute branch where supported |
| Expected regulation / post-tie treatment | Three 20-minute periods, tied regulation game adds exactly one credited deciding goal in OT/SO under the framework convention; actual local operator terms unverified |
| Official puck-drop evidence | Schedule confirmed; **actual first-puck time and delay not independently verified** |
| Timing | Research began before scheduled 00:30 AEDT; local save/issue: **2026-11-13T00:28:42+11:00**; no outcome data used. `PRE_SCHEDULED_START_RESEARCH / ACTUAL_START_UNVERIFIED / CHAT_ONLY` |
| Local status | NEW_EVENT, first Torpedo–Arlan game only, not frozen, no canonical allocation |

### A2 — Authority, duplicate and reading receipt

- Main-branch reference `008cedc4ff469e7a808292aa3667a7bffe22e273` (MDS v24.16; prompt suite P-v24.14, SCV-v13, SEL-v4; chat-local no-push owner override). Source controls reviewed: `CORE.md`; `CURRENT_STATE.md`; `WORKFLOW.md`; `research/prompts/1_GAME_CARD.md` (applicable shared steps); `research/prompts/1_sports/ICE_HOCKEY.md`; `RULES_ICE_HOCKEY.md` §0; `GAME_REQUEST_TEMPLATE.md` §1b; `PARAMETERS.md` Part A; `PROBABILITY_TOOLKIT.md` count formula via custom finite-grid calculation; existing mini entire text. Repo exact referenced hash **not** a validated local HEAD, and the owner's worktree/lease not inspected.
- Verified no matching event in this existing chat-local mini; `G0001` is an unrelated tennis match. Global canonical duplicate scan incomplete; cannot claim global uniqueness or official repository issuance. Next event key allocated **only in chat-local draft namespace**.
- `P-639` is canonical **context only**; zero P IDs assigned.

### A3 — Historical form, opponent adjustment and availability

**Official league table before event (26 matches each):** Torpedo 18 regulation wins, 2 OT wins, 1 SO win, 1 SO loss, 1 OT loss, 3 regulation losses, **138 GF / 46 GA** (5.308 / 1.769 per game). Arlan 18 regulation wins, 1 OT win, 1 SO win, 0 SO losses, 1 OT loss, 5 regulation losses, **92 GF / 58 GA** (3.538 / 2.231). Torpedo first, Arlan third. Official league scoring pool: **831** team goals across **254** team-games (127 games), or **3.271654** goals per team-game. These official final-score rates **may contain OT/SO and 5–0 administrative awards**, not a 60-minute-pure or quality-adjusted dataset.

**All results in the following true L5/L10/L15/L20 windows are dated and from the current 2026/27 Pro Hokei Ligasy schedule.** GF–GA shown from named team's perspective, final scoreboard. Over/Under uses final goals, not an inferred regulation tally. Awarded Arlan 5–0 result on 22 September is **excluded** from played-score form (thus L20 has actual n=19, no synthetic 5-goal datum). Original records include OT/SO finals, not an inflated period score.

| Team | Requested window | Played n | GF–GA | Mean total | Under 6.5 | Team −1.5 covers |
|---|---|---:|---:|---:|---:|---:|
| Torpedo | L5 | 5 | 20–6 | 5.20 | 4/5 | 5/5 |
| Arlan | L5 | 5 | 23–7 | 6.00 | 3/5 | 3/5 |
| Torpedo | L10 | 10 | 71–10 | 8.10 | 4/10 | 10/10 |
| Arlan | L10 | 10 | 38–21 | 5.90 | 7/10 | 4/10 |
| Torpedo | L15 | 15 | 94–23 | 7.80 | 6/15 | 12/15 |
| Arlan | L15 | 15 | 55–34 | 5.93 | 9/15 | 5/15 |
| Torpedo | L20 | 20 | 117–34 | 7.55 | 8/20 | 14/20 |
| Arlan | L20 | 19 | 72–42 | 6.00 | 11/19 | 7/19 |

**Torpedo last 20, newest first:**

| Date | Opponent | GF–GA | Outcome |
|---|---|---|---|
| 2026-10-30 | Nomad | 3–0 | Reg |
| 2026-10-29 | Nomad | 6–3 | Reg |
| 2026-10-26 | Aqtobe | 3–1 | Reg |
| 2026-10-25 | Aqtobe | 4–2 | Reg |
| 2026-10-20 | Almaty | 4–0 | Reg |
| 2026-10-19 | Almaty | 9–1 | Reg |
| 2026-10-16 | Ertis | 12–1 | Reg |
| 2026-10-15 | Ertis | 9–2 | Reg |
| 2026-10-12 | Ertis | 8–0 | Reg |
| 2026-10-11 | Ertis | 13–0 | Reg |
| 2026-10-07 | Nomad | 2–3 | SO |
| 2026-10-06 | Nomad | 2–3 | OT |
| 2026-10-02 | Beibarys | 9–2 | Reg |
| 2026-10-01 | Beibarys | 4–3 | Reg |
| 2026-09-28 | Aqtobe | 6–2 | Reg |
| 2026-09-27 | Aqtobe | 9–1 | Reg |
| 2026-09-21 | Gornyak | 1–2 | Reg |
| 2026-09-20 | Gornyak | 4–3 | Reg |
| 2026-09-17 | Qulager | 6–3 | Reg |
| 2026-09-16 | Qulager | 3–2 | OT |

**Arlan last 20 fixture records, newest first (one technical award):**

| Date | Opponent | GF–GA | Outcome |
|---|---|---|---|
| 2026-10-30 | Gornyak | 4–0 | Reg |
| 2026-10-29 | Gornyak | 3–2 | Reg |
| 2026-10-26 | Almaty | 4–3 | Reg |
| 2026-10-25 | Almaty | 3–0 | Reg |
| 2026-10-21 | Ertis | 9–2 | Reg |
| 2026-10-20 | Ertis | 5–1 | Reg |
| 2026-10-15 | Saryarqa | 4–3 | SO |
| 2026-10-14 | Saryarqa | 1–4 | Reg |
| 2026-10-11 | Nomad | 2–4 | Reg |
| 2026-10-10 | Nomad | 3–2 | OT |
| 2026-10-07 | Qulager | 4–3 | Reg |
| 2026-10-06 | Qulager | 4–3 | Reg |
| 2026-10-03 | Almaty | 3–2 | Reg |
| 2026-10-02 | Almaty | 1–2 | Reg |
| 2026-09-28 | Ertis | 5–3 | Reg |
| 2026-09-27 | Ertis | 11–2 | Reg |
| 2026-09-23 | Saryarqa | 2–5 | Reg |
| 2026-09-22 | Saryarqa | 5–0 | TECH |
| 2026-09-16 | Beibarys | 1–0 | Reg |
| 2026-09-15 | Beibarys | 3–1 | Reg |

**Critical opponent-strength control:** Torpedo's **four** games against Ertis on 11–16 October yielded **42–3** goals; Ertis is bottom with **31–187** goals and one point from 24 league games. Torpedo's last ten against non-Ertis opponents: **29 GF / 7 GA in 6 games**, rather than blindly extrapolating 7.1 team goals/game. Arlan's last ten excluding two Ertis matches: **24 GF / 18 GA in 8 games**. Opponent adjustments are qualitative; no full schedule-strength fitted model was available. Never import Ertis blowouts as expected Torpedo scoring versus third-place Arlan.

**H2H, most recent ten mixed competition meetings (final score from Torpedo viewpoint; cup games marked):**

| Date | Score (Torpedo–Arlan) | Competition / endpoint | Total |
|---|---|---|---:|
| 2026-09-07 | 4–3 (OT) | Pro league | 7 |
| 2026-09-06 | 2–3 | Pro league | 5 |
| 2026-08-14 | 3–2 | Kazakhstan Cup; different competition | 5 |
| 2026-02-15 | 5–2 | Pro league | 7 |
| 2026-02-14 | 3–1 | Pro league | 4 |
| 2025-12-06 | 1–2 | Pro league | 3 |
| 2025-12-05 | 4–1 | Pro league | 5 |
| 2025-09-08 | 9–0 | Pro league | 9 |
| 2025-09-07 | 3–4 (SO) | Pro league | 7 |
| 2025-08-28 | 3–2 | Kazakhstan Cup; different competition | 5 |

**Same-league H2H:** 4 Under 6.5 in 8 league fixtures, not 6/10 mixed-competition as a same-league claim. In this season's 2 league H2Hs, one 5-goal and one 7-goal game; Torpedo did **not** clear −1.5 in either. Unadjusted low-n observations, not a probability model.

**Goalies/rosters:** The Torpedo club site lists Anton Osokin (season **94.2%** save percentage) and Sergey Kudryavtsev (**91.6%**); this **does not identify the 12 Nov starting goalie**. No exact-game starting goalkeeper, scratch/line combinations, confirmed goalie quality for Arlan, current injury/illness/disciplinary release or special-teams xG/shot-quality lineup has been independently confirmed. `STARTING_GOALIES_UNCONFIRMED_BOTH / LINEUPS_UNCONFIRMED_BOTH / INJURIES_NOT_VERIFIED` — not evidence of no injuries or either athlete's participation. No speculative substitution effect applied.

### A4 — Conditional scoring diagnostic, methods and mathematics (NOT PRIMARY)

`REFERENCE_TIER: C / NONE` for Kazakhstan (no registered accepted local-league reference/goalie model verified); `BASELINE_LEAGUE_V1: ATTEMPTED_NOT_FROZEN`, `MODEL_STAGE: NOT_RUN_NO_RELEASE_VERIFIED`, `OFFICIAL_CARD_FREEZE: NOT_RUN`, `ANALYST_PRIMARY_V1: NOT_ISSUED`, `BOOKMAKER_INPUT: NONE`.

A **transparent hand-coded finite-grid sensitivity calculation**, not the repo's unvalidated hockey simulator and **not a calibrated card model**:

1. Exact-competition empirical mean (final score basis): `L = 831 / 254 = 3.271653543` team goals/game. Season team per-game GF/GA as in A3. Multiplicative rate proxy, with **no independently estimated home effect**: `λ_T = (138/26)*(58/26)/L = 3.619037`, `λ_A = (92/26)*(46/26)/L = 1.913514` goals per presumed regulation event. This proxy is **not true opponent-by-opponent adjustment**; final-score rates imperfectly proxy regulation rates, and sampling/awards cause bias.
2. Construct `P(X=i,Y=j)=Poisson(i;λ_T)*Poisson(j;λ_A)` for `i,j=0..25`; tail mass **2.56e-14**. Goal counts independent conditional on these rates; **covariance 0 assumed, not evidenced**.
3. For **regulation ties** `i=j`, add one scoreboard goal to either side under the framework OT/SO convention; conditional winner assignment on ties is **NOT_ESTIMATED**, but that winner does not alter the listed −1.5 or 6.5 outcomes. `P(regulation tie)=13.6417%`; 3–3 tie branch exactly `3.6493%` moves regulation Under 6.5 to full-game Over 6.5. **Empty-net/pulled-goalie events are not separately estimated**; the base final-score means already mix them as inputs, so no invented extra tail probability is applied.
4. P(Torpedo −1.5)=Σ_(i−j≥2) P(i,j); P(Arlan +1.5)=complement, including ties/OT; P(Under 6.5 FULL)=Σ_{i+j+1[i=j]≤6} P(i,j). No push for half-goal lines, all unconditional W+L=1. Event regulation masses: T wins **69.4848%**, draw **13.6417%**, Arlan wins **16.8735%**. Full match winner probability **NOT_ESTIMATED** (no credible OT-specific winner model).
5. **Conditional base expected regulation score:** Torpedo `3.62` – Arlan `1.91`, regulation total `5.53`, assumed final total with automatic tie-winning goal `5.67`. Regulation score standard deviations ≈ √λ_T=1.90, √λ_A=1.38, regulation total √(λ_T+λ_A)=2.35, margin same under independence. **No additional EN covariance or uncertainty quantified.**

| Exact supplied outcome | Base conditional chance | Full-game endpoint disposition |
|---|---:|---|
| **Under 6.5 goals** | **64.44%** | Highest numeric conditional lean; **NOT certified ranked total** with goalies unconfirmed |
| Torpedo −1.5 goals | 52.62% | Directional favorite; narrow margin, not a robust cover |
| Arlan +1.5 goals | 47.38% | Complement of Torpedo handicap; possible one-goal game |
| Over 6.5 goals | 35.56% | Complement of Under; blowout/goalie risk |

**Regulation-only total branch:** Under 6.5 = `68.09%` under same goal grid, compared with `64.44%` including OT/SO credited goal. **Operator definition unknown**: report both; do not claim an operator's settlement convention.

**Sensitivity (plausible rate scenarios, not estimated confidence intervals):**

| Scenario (λ_T, λ_A) | Full Under 6.5 | Torpedo −1.5 | Arlan +1.5 | What is tested |
|---|---:|---:|---:|---|
| Lower scoring (3.20, 1.60) | 76.0% | 50.7% | 49.3% | Tighter goaltending, less conversion |
| Season-rate base (3.62, 1.91) | 64.4% | 52.6% | 47.4% | Multiplicative final-score rate proxy |
| Balanced high (3.35, 2.55) | 57.5% | 38.0% | 62.0% | Arlan produces more offense; cover reverses |
| High scoring (4.00, 2.40) | 50.1% | 50.9% | 49.1% | Weaker goaltending / extra scoring |

The broad ~50–76% sensitivity for Under and ~38–53% for Torpedo −1.5 confirms neither directional outcome is a **safe calibrated forecast**. **No 100,000-run Monte Carlo, NHL simulator, documented freeze receipt, fitter, model promotion, league baseline release or source audit was run**; arithmetic is a deterministic exact finite grid only. Reproduce via chat-local `hockey_diagnostic_20261113.py` (outside GitHub).

### A5 — Selection, full supplied universe and dependence

- Full supplied universe: Torpedo −1.5, Arlan +1.5, Under 6.5 and Over 6.5, all assessed above; no other contract introduced, no odds and no EV derived.
- **Best numerical directional lean (conditional): UNDER 6.5 goals.** **Abstain for low-risk formal selection**: goalie identities and operator definition unresolved, threshold estimate depends heavily on goal rates, insufficient calibration. This is not an official repo Rank 1 because the ice-hockey rule `IH-P2` blocks an unconfirmed-goalie total from leading sparse/early-league cards.
- First pair of alternatives total Under and handicap Torpedo −1.5 share **unestimated dependence**. Not two independent picks; no joint-failure probability invented.
- Printed conditional p values sum to 100% for each two-sided line (within rounding); `PICKS_V2` formal linter/selection ceiling **NOT_EXECUTED**; `p_card` and `baseline_p` not published.

### A6 — Context, rules, venue and fatigue

- Venue Torpedo home at Boris Alexandrov Sports Palace, not neutral. No environment/wind variable (indoor ice rink). No measured current competition-specific home-court effect added.
- Latest completed league game for both teams **30 October**; roughly 12 calendar days without a scheduled league game, so no source-supported back-to-back fatigue adjustment. Practice/exhibition and injury status remain unverified.
- Torpedo's Oct 29–30 home series vs Nomad (6–3, 3–0) gives useful stronger-opponent context; Arlan's Oct 29–30 wins at Gornyak (3–2, 4–0) also show defense, but not as difficult as Torpedo at home.
- Home/away, special-teams efficiency, coach tactical changes and individual line matchups have **no validated event-specific quantified effect** here; do not copy NHL-specific effect sizes to Kazakhstan.
- The following day's Torpedo–Arlan rematch is a separate event and not part of this card.
- Shootout goal adds one to the score under framework default; actual puck-line/totals operator settlement, game official report and empty-net tail remain `UNKNOWN_DEFINITION`/`NOT_VERIFIED` for prospective validation.

### A7 — Risk, limits, audit and decision rationale

**Strongest total argument:** the 6.5 threshold sits above the base matchup-specific goal mean and above Arlan's last-20 played-game mean. Torpedo's huge season offense is inflated by much weaker opponents; H2H is competitive and often tight. Conversely, Torpedo is elite offensively and a confirmed non-first-choice goalie or open game could lift the total. The Under probability falls near 50% in a plausible high-scoring scenario; avoid confidence inflation.

**Handicap risk:** Torpedo is favored outright by the point-score direction but its −1.5 condition is not the same as winning; close H2Hs and late pulled-goalie uncertainty dominate. Arlan +1.5 has structural cover routes (one-goal regulation and OT/SO, or straight win), so neither handicap side receives a high-confidence grade. A full-regulation score grid does not establish a trusted EN-augmented final margin.

`UNCALIBRATED_SHADOW_DIAGNOSTIC`; no official model activation, no reference receipt, no issue timestamp verified by GitHub, no formal ledger, no source-audit provenance certification, not performance eligible. `No strong pick / ABSTAIN: YES`. Settlement `NOT_PERFORMED`.

### A8 — Sources, retrieval, publication clocks and access gaps

All actual web evidence was discovered and checked **12 Nov 2026 approximately 13:18–13:24 UTC (13 Nov 00:18–00:24 AEDT)**. The exact second per URL was **not captured**; indexed page crawl/update timestamps are distinct from publication and request clocks. No future-game result/live page was consulted as an outcome. GitHub main pinned in previous audit; repository-local source permission command `python -m ml source-audit --url ... --reader CLAUDE_AGENT` **not executed** because there is no local repo checkout in this chat environment; remote page reachability does not establish repo-agent access authorization.

| Source URL | Evidence used | Custody / limitation |
|---|---|---|
| https://phl.ligasy.kz/ru/schedule/?id_team=12 | League first game id 131 vs rematch id 133, 18:30 local | indexed pregame schedule, actual start not proven |
| https://phl.ligasy.kz/ru/standings | 26-game records, all league goals, Ertis extreme | league final-score data; one awarded 5–0 included in official totals |
| https://pro.ligasy.kz/ru/team/12-torpedo/schedule/16-pro-hokei-ligasy-2026-2027?id_tab=articles&id_team=12&start=100 | Torpedo latest results / 10-window | indexed official text, no retrieved raw archive hash |
| https://pro.ligasy.kz/ru/schedule/2026?id_team=12 | Torpedo older September/October results | search discovery and indexed official schedule |
| https://pro.ligasy.kz/ru/team/2-arlan | Arlan full September/October 2026 results, technical 5–0 | indexed official team schedule, explicit TECH exclusion |
| https://shaiba.kz/match/39380/torpedo-arlan/12-11-2026 | ten prior H2H scores and OT/SO labels; unstarted-state snapshot | indexed sports score provider; direct opening failed, no certified actual first-puck time |
| https://hctorpedo.pro/ | Club venue, goalie season save-% and club player news | roster/goalie statistical identity, **not confirmed starter** |
| https://afisha.yandex.kz/ust-kamenogorsk/sport/hockey-torpedo-arlan | Venue and two consecutive home dates | ticket listing; independent game schedule corroboration |

Unverified material: event-specific starters and scratches; both goaltenders; Arlan goalie performance, late releases and injuries; special teams/shots/xG; independent source-collector lineage/field timestamps; whether sportsbook lines are regulation-only; game delay/actual first puck; official full-game freeze. All remain **UNRESOLVED** and no automation was scheduled.

### A9 — Completion / custody matrix

| Step | Evidence and disposition | Next precise action |
|---|---|---|
| 1 Authority | `READ_ONLY_PUBLISHED_MAIN_REFERENCE`, full local mini inspected, no authorized repository writer | Run checked-out HEAD/dirty-tree/lease verification in owner repo only if officially issuing, not authorized here |
| 2 Identity/time | `SCHEDULE_VERIFIED`, home/round, native #131; status `ACTUAL_START_UNVERIFIED` | Opening faceoff timestamp/status from official 131 game sheet |
| 3 Forms/availability | `L5/L10/L15/L20 COMPLETED` with true n and one technical 5–0 excluded; **GOALIES/LINEUPS_UNCONFIRMED** | Exact match-sheet goalies, absence list, eligible skaters and special teams for both teams |
| 4 Distribution | `EXECUTED_LOCAL_CONDITIONAL_POISSON_GRID`, validated sum to 1; baseline and repository freeze absent | Competition-calibrated reference, opponent-adjusted xG or exact goalies, EN/OT mechanism with supported sizes |
| 5 Selection | Both handicap and both total directions assessed; `ABSTAIN` | No formal card until required numerical and issuer gates pass |
| 6 Context/rules | Home venue/date, rest and OT/SO convention checked; operator terms not | Confirm exact operator market and regulation/OT grading |
| 7 Local write/audit | This new G0002 research draft, original G0001 preserved; readback to follow | Verify updated entire local mini, intake ordinal, running footer and hashes |

**Research completeness:** `INFORMATION_INCOMPLETE` due to missing starters/special-teams/settlement definition and source-audit access. **Numerical lane:** `LOCAL_UNCALIBRATED_DIAGNOSTIC_EXECUTED`; **official reference/issuance:** `NOT_PERFORMED`; **canonical ID:** `NOT_ASSIGNED`; **results check/settlement:** `NOT_PERFORMED`; **automation:** `NONE`; **GitHub writes:** `NONE`.
<!-- END CHAT_LOCAL_DRAFT LOCAL-202611128358B025-G0002 -->


<!-- BEGIN CHAT_LOCAL_DRAFT LOCAL-202611128358B025-G0003 -->
## Research card G0003 — Thiago Agustín Tirante vs Aleksandr Shevchenko, Stockholm ATP 2026

**Classification:** `CHAT_LOCAL_RESEARCH_DRAFT` / `INFORMATION_INCOMPLETE` / `POST_SCHEDULED_START_ISSUE` / `ACTUAL_FIRST_SERVE_UNVERIFIED`. `REPOSITORY_CARD_ISSUED: NO`; `CANONICAL_ID: NOT_ASSIGNED`; `OFFICIAL_REFERENCE_FREEZE: NOT_PERFORMED`; `OFFICIAL_MODEL_RUN: NOT_PERFORMED`; `SETTLEMENT: NOT_PERFORMED`; `OUTCOME_EXPOSURE: NOT_INTENTIONALLY_CONSULTED`; `GITHUB_WRITE: NONE`. Numerical diagnostics are conditional uncalibrated calculations and **not** official `p_card` or formally performance-eligible prospective predictions.

### A1. Authority, identity, request and timing

| Field | Evidence and resolution |
|---|---|
| Local event key | `LOCAL-202611128358B025-G0003` (immutable; no canonical allocation) |
| User request | `Upcoming Tennis Match: Thiago Agustin vs Alexander Shevchenko, ATP Stockholm - 1/4 Final`; requested `Tirante +0.5 games`, `Shevchenko -0.5 games`, `Over/Under 23.5 total games`; estimated 2026-11-13 01:00 AEDT |
| Resolved identities | Thiago Agustín Tirante (ARG, ATP ranking ~51) and Aleksandr/Alexander Shevchenko (KAZ, ATP ranking ~107); first name-only alias `Thiago Agustin` resolved by supplied surname `Tirante` |
| Competition and format | Stockholm Open 2026, ATP 250 men's singles, QF, Centre Court, Stockholm, indoor hard, best of 3 standard sets with tie-break at 6–6 |
| Official schedule | Thu 12 Nov 2026, *not before 15:00 CET* = 14:00 UTC = Fri 13 Nov 01:00 AEDT; match can be later if earlier Centre Court match overran |
| User-arrival evidence | 2026-11-13 00:59+11:00 minute from conversation; exact seconds not shown |
| Research/issue time | 2026-11-13T01:08:35+11:00; after the scheduled threshold; actual first serve independent verification `NOT_VERIFIED` |
| Repo authority | Connected GitHub `danisgreat/Sports-Research` `main` previously read pinned SHA `008cedc4ff469e7a808292aa3667a7bffe22e273`; mini-log-10; MDS-2026.11.11-v24.16; P-2026.11.11-v24.14; SCV-2026.11.11-v13; SEL-2026.10.22-v4; read-only research outside repository checkout |
| Endpoint | Game handicap on completed match total games (not match ML or set spread); totals on complete best-of-three match. Retirement/walkover treatment depends on user operator: `UNKNOWN_DEFINITION` |
| Duplicate check | This mini G0001 is Svrčina–Virtanen, G0002 Torpedo–Arlan; this event has not previously been appended here. Other authors' local minis and canonical event body not exhaustively checked. |

### A2. Draw verification, venue, matchup

- Official Stockholm tournament schedule: https://www.stockholmopen.se/en/tournament/spelschema (Centre Court QF not-before 15:00 local). The 15:00 CET time is **not** proof of actual first serve or a completed match.
- Official Stockholm tournament H2H/record: https://www.stockholmopen.se/en/tournament/head-to-head/singles/ea24/t0a1 reports Tirante advanced from R16 against Tomás Martín Etcheverry via **WALKOVER** (W/O), not a played match. Supporting competition path: https://tennis-db.com/matches/4760444/thiago-agustin-tirante-vs-tomas-martin-etcheverry. Walkover excluded from played form and game totals.
- Prior player H2H: one documented outdoor hard-court meeting, 18 March 2025 Miami qualifying, Tirante beat Shevchenko 6–3, 6–3; H2H 1–0; no documented indoor meeting. Sources: https://www.tennis.com/tournaments/stockholm-open/matches/t-tirante-vs-a-shevchenko-2026-11-12 and https://theworldoftennis.com/match/aleksandr-shevchenko-thiago-agustin-tirante/.
- Court: indoor hard; weather excluded; official ball/court speed and each player's exact injury report not verified. Both are match entrants, which does not prove healthy fitness.

### A3. Prior results, form, surface, workload and availability

**Recent fully played matches (most recent first; W/O excluded):**

| Player | Date | Opponent | Result and score | Tournament/surface |
|---|---|---|---|---|
| Tirante | Nov 8 | Jaume Munar | W 7–6(3), 6–3 | Stockholm indoor hard |
| Tirante | Nov 4 | Jan-Lennard Struff | L 7–6(5), 3–6, 6–7(3) | Paris indoor hard |
| Tirante | Nov 1 | Mattia Bellucci | L 4–6, 4–6 | Paris indoor hard |
| Tirante | Oct 31 | Zachary Svajda | W 3–6, 6–1, 6–4 | Paris indoor hard |
| Tirante | Oct 24 | Adrian Mannarino | L 4–6, 6–7(5) | Vienna indoor hard |
| Shevchenko | Nov 11 | Casper Ruud | W 6–7(5), 6–4, 6–3 | Stockholm indoor hard |
| Shevchenko | Nov 10 | Adrian Mannarino | W 6–1, 6–3 | Stockholm indoor hard |
| Shevchenko | Nov 8 | Jacob Fearnley | W 6–2, 6–4 | Stockholm qualifying, indoor hard |
| Shevchenko | Nov 7 | Viktor Durasovic | W 6–1, 6–1 | Stockholm qualifying, indoor hard |
| Shevchenko | Nov 2 | Luka Pavlovic | L 3–6, 6–4, 4–6 | Bratislava indoor hard |

| Window / field | Tirante | Shevchenko | Integrity |
|---|---|---|---|
| L5 | 2–3, n=5 played | 4–1, n=5 played | Individual scores listed above; W/O removed |
| L10 | 4–6, n=10 played | 7–3, n=10 played | Summary corroborated by match-history pages, not rebuilt independently as 20 dated rows |
| L15 | `NOT_VERIFIED`, true n incomplete | `NOT_VERIFIED`, true n incomplete | Complete dated last-15 extraction was not achieved |
| L20 | `NOT_VERIFIED`, true n incomplete | `NOT_VERIFIED`, true n incomplete | Complete dated last-20 extraction was not achieved |
| 2026 indoor record (source-dependent) | 3–4 | 9–5 on TennisExplorer; another provider says 6–4 | Providers disagree on scope; exact sample inclusion not reconciled, so only directional |
| Rest/workload | Last *played* match Nov 8, R16 was walkover | Played four Stockholm matches Nov 7/8/10/11, Ruud match three sets Nov 11 | Rest advantage Tirante; quantified fatigue adjustment **NOT_ESTIMATED** |
| Injury, fitness/withdrawal | No confirmed injury status established | No confirmed injury status established | `FITNESS_NOT_VERIFIED`, not assumed healthy |

Historical sources: https://www.betexplorer.com/tennis/team/tirante-thiago-agustin/jBkGDj34/results/ (scores only; no market info used), https://tennistale.com/tournaments/atp/2026/stockholm (draw/results), https://tennisforesight.com/match/12179510-tirante-vs-shevchenko-stockholm (historical result rows only, no predictions used), https://umpiry.com/match/2026-11-12/shevchenko-vs-tirante-stockholm-qf (form history), https://noproxy.tennisexplorer.com/match-detail/?id=3377329 (surface summary returned in search; later page-open failed with cache miss). Coverage: L5 corroborated, L10 partial independent summary, L15/20 missing.

### A4. Point-to-match diagnostic and controls

**Reference:** `TENNIS REFMODEL tier C / NONE` per repository sport rules; executable `python -m ml reference tier --competition "Tennis/ATP"` **NOT_RUN** because authenticated repo executable checkout is not present in this workspace. Competition-only matched-line baseline `NOT_COMPUTED`; separate prospective reference freeze `NOT_PERFORMED`. The Tennis Abstract official 50/50 overall-hard Elo audit and exact effect-table calibration were **NOT_COMPLETED**. Accordingly no official `p_card` is published.

**Observed aggregates (non-competition-specific and not confirmed indoor-only):** a tennis match-statistics provider reported Tirante **64.6% service points won, 36.0% return points won**, and Shevchenko **60.1% service points won, 35.7% return points won**. It reported held service games approximately 81.2% and 74.1% respectively. Exact observation-window and opponent-standardization are not source-certified; other provider sample definitions differ. Source: https://theworldoftennis.com/match/aleksandr-shevchenko-thiago-agustin-tirante/.

**Neutral point-level blend**, fully disclosed, not calibrated: `p(Tirante point on serve) = [0.646 + (1−0.357)]/2 = 0.6445`; `p(Shevchenko point on serve) = [0.601 + (1−0.360)]/2 = 0.6205`. Standard advantage-set-game hold formula: `p_hold = p^4 (1 + 4q + 10q²) + 20 p³ q³ [p²/(p²+q²)]`, q=1−p. Result: Tirante serve-game hold `0.82039`, Shevchenko `0.77682`. Enumerate every legal best-of-three match set score, with alternating server, independent service points, 7-point tiebreak at 6–6, and half the weight assigned to either initial server; 224 aggregated completed score states and sum-of-mass=1. No fitted match-level form shock, fatigue effect or indoor-strength coefficient; these are scenario inputs, not observed causal parameters.

**Executed local diagnostic:** `/mnt/data/tennis_stockholm_scenario_20261113.py`; script run in local Python; no official repository kit run, receipt, certified freeze, train/test, or independent quality assessment. Point-level deuce tiebreak recursion truncation at 120 points with negligible tail assigned 0.5; not validated against operator-specific tiebreak exception. Neutral scenario produces `P(Tirante match winner)=0.61855`, `E(Tirante games)=13.240`, `E(Shevchenko games)=12.086`, `E(total)=25.325`, `P(3 sets)=0.48729`. The match winner probability is a diagnostic, not a requested ML or published certified estimate.

**Illustrative indoor-strength counterfactual** (not a fitted adjustment): lower Tirante service-point win to 0.6365, raise Shevchenko to 0.6305. Coherent enumeration gives `E(Tirante games)=12.910`, `E(Shevchenko games)=12.620`, `E(total)=25.530`, `P(3 sets)=0.49920`, `P(Tirante match winner)=0.53003`. This scenario responds directionally to Shevchenko's stronger indoor form but its sizes are assumptions, *not verified effect-table rows*.

### A5. All exact supplied contracts and candidate selection

For every completed best-of-three match, integer total games and integer games margin mean the user-supplied half lines are complementary two-way events without pushes. `W + L = 1`; `P(push)=0` and `V(void)=0` **conditional on a fully completed match**. Retirement/walkover rules remain operator-dependent and are outside the scored completed-match sample.

| Rank within illustrative indoor scenario | Supplied contract | Neutral unadjusted scenario | Illustrative indoor scenario | W/P/L/V in indoor scenario | Disposition |
|---|---|---:|---:|---|---|
| 1 | **Over 23.5 total games** | 53.26% | **54.60%** | 0.54602 / 0 / 0.45398 / 0 | Weak directional lean; **ABSTAIN** |
| 2 | Tirante +0.5 games | 59.69% | 50.59% | 0.50591 / 0 / 0.49409 / 0 | Too sensitive to indoor player strength |
| 3 | Shevchenko −0.5 games | 40.31% | 49.41% | 0.49409 / 0 / 0.50591 / 0 | Sensitive counterparty complement |
| 4 | Under 23.5 total games | 46.74% | 45.40% | 0.45398 / 0 / 0.54602 / 0 | Not preferred in these scenarios |

**Ranking status:** directional scenario order only; official `PICKS_V2` NOT_ISSUED because Tier-C reference/kit freeze, player effect-table ledger, actual start status and historical source completeness were not verified. Official `model_p`: `NONE`. **ABSTAIN=YES** for a low-risk request. No simulation claim or market information used. No canonical P-ID reserved.

**Handicap vs match-win distinction:** A player may win the match while finishing behind on total games, or lose three sets while winning more games. The code sums the requested *games margin* over all completed match score states, not only winning matches, in line with PROBABILITY_TOOLKIT §6. The neutral grid's Tirante match-winner probability of 61.86% differs from his +0.5 games chance of 59.69%; do not substitute ML for spread.

### A6. Playing rules, endpoint and settlement definition

- ATP best-of-three: each normal set to six games by two, tiebreak at six-all; final set handled with same standard tiebreak in the diagnostic. Result depends on full match completion.
- `Over 23.5` wins on 24+ combined games; `Under 23.5` on <=23. `Tirante +0.5` wins if total games won by Tirante exceeds Shevchenko; Shevchenko −0.5 is the exact complement.
- Match completion, abandonment, retirement and market-specific settlement treatment `UNKNOWN_DEFINITION`; ask operator terms only if settlement is later requested. Actual first serve and in-play status are not independently verified, so never relabel local issue as prospective pre-start.
- Indoor court removes weather/wind considerations; venue and ball speed unverified.

### A7. Sensitivity, dependence and limitations

All four supplied rows are priced from the same tennis complete-match grid (not independent event probabilities). Selected diagnostic scenarios:

| Scenario | p serve Tirante | p serve Shevchenko | Tirante +0.5 | Shevchenko −0.5 | Over 23.5 | Under 23.5 |
|---|---:|---:|---:|---:|---:|---:|
| Neutral unadjusted | .6445 | .6205 | .59685 | .40315 | .53260 | .46740 |
| Illustrative indoor Shevchenko boost | .6365 | .6305 | .50591 | .49409 | .54602 | .45398 |
| Both players +1.5pp service-point ability | .6595 | .6355 | .59398 | .40602 | .54197 | .45803 |
| Both players −1.5pp service-point ability | .6295 | .6055 | .59945 | .40055 | .52463 | .47537 |
| Larger Shevchenko comparative advantage | .6295 | .6405 | .41980 | .58020 | .54483 | .45517 |

Ranges are *scenario spans, not confidence intervals*: Tirante +0.5 ~42–60%, Over 23.5 ~52–55%. The total's weak directional advantage is more stable across these assumed point-strength scenarios, but not empirically calibrated and not strong. Break-point clutch, injury, fatigue and indoor aggregate-scope differences could move the prices differently. H2H 1-0 is descriptive, not proof of a causal edge. Cross-contract joint failure not separately priced; cannot claim independence. No verified historical same-endpoint league-only baseline.

### A8. Source receipt, failures, route and known-at

| Source | Evidence used | Access or timing limitation |
|---|---|---|
| https://www.stockholmopen.se/en/tournament/spelschema | Official day/court/round/not-before start | Dynamic schedule display; actual first serve `NOT_VERIFIED` |
| https://www.stockholmopen.se/en/tournament/head-to-head/singles/ea24/t0a1 | Official Tirante walkover and players | Exact official W/O supported |
| https://www.tennis.com/tournaments/stockholm-open/matches/t-tirante-vs-a-shevchenko-2026-11-12 | ATP rank and past meeting | A time-stamped source snapshot prior to first serve not captured |
| https://tennistale.com/tournaments/atp/2026/stockholm | Shev 6–7 6–4 6–3 over Ruud; recent Stockholm draw | Structured third-party, known-at timestamps mostly unknown |
| https://www.betexplorer.com/tennis/team/tirante-thiago-agustin/jBkGDj34/results/ | Tirante completed recent scores and W/O (results only) | Betting-hosted result page; no odds or predictions ingested |
| https://tennisforesight.com/match/12179510-tirante-vs-shevchenko-stockholm | Summary last 5 and prior results only | Model/betting commentary explicitly not ingested |
| https://umpiry.com/match/2026-11-12/shevchenko-vs-tirante-stockholm-qf | Last 10 summary and common opponents | Provider collection/independence not certified |
| https://theworldoftennis.com/match/aleksandr-shevchenko-thiago-agustin-tirante/ | Match-level serve/return aggregated statistics and indoor record | Aggregation scope unclear; attempted page open later technical cache miss |
| https://noproxy.tennisexplorer.com/match-detail/?id=3377329 | Alternate indoor record | Page open cache miss; returned search snippet only |

**Access compliance limits:** no pinned repository Python checkout in this chat; `python -m ml source-audit --reader CLAUDE_AGENT`, `history-pack`, `reference tier`, `kit verify`, and `pregame run` were **NOT_RUN**. Do not report source-reader permission as successfully audited. Sources used are public search/open results; a subsequent repository agent must do full allowed-source audit and capture before any formal card or statistical cohort admission. Publication/pregame-known-at clocks are not reproducible from these snippets, so `KNOWN_AT_UNVERIFIED` applies to decisive aggregates. No owner captures, independent collector attestations, qualified tennis release or operator terms exist. No external research lanes were launched.

### A9. Research-completion matrix and outstanding queue

| Mandatory sport step | Actual status | Required closure to qualify |
|---|---|---|
| 1 Authority | `PINNED_REPO_READ_ONLY`, sport/control snapshot read, no writable repo checkout | Verify HEAD/working-tree differences and execution writer lease in repository before issuance |
| 2 Fixture/identity/timing | Official event/date/indoor/QF/estimated time `VERIFIED`; first serve `NOT_VERIFIED`; issue after scheduled threshold | Actual first-serve timestamp/phase and frozen known-at evidence; post-schedule issue cannot be represented as pre-start issue |
| 3 Historical form/availability | L5 played samples and L10 summaries retained, H2H and current walkover checked; `INFORMATION_INCOMPLETE` | True dated L15/L20, permitted source checks, surface-weighted Elo at date, fitness/withdrawal report and source lineage |
| 4 Distribution | Conditional exact game/set match score enumeration `EXECUTED_LOCAL_DIAGNOSTIC`; formal calibration/reference/freeze `NOT_RUN` | Source-verified player inputs, fitted form shock or explicit unavailability, competition baseline, official repo reference/kit receipt |
| 5 Contracts/ranks | Both handicap and both total sides calculated from common score grid; `ABSTAIN=YES`; official `PICKS_V2 NOT_ISSUED` | Verified adjustment ledger, typed freeze and test/quality gate |
| 6 Tennis rules | Best-of-three/tiebreak and half-game arithmetic resolved; retirement operator policy `UNKNOWN_DEFINITION` | Operator-specific settlement on retirement and official format exception if any |
| 7 Retention | G0003 chat-local append/readback, old G0001/G0002 cores immutable, updated intake/footer | Return complete local Markdown; no repo writer/push/official issue claimed |

**Research completeness:** `INFORMATION_INCOMPLETE`; **numerical execution:** `LOCAL_UNCALIBRATED_CONDITIONAL_GRID`; **formal forecast/mini issue:** `NOT_PERFORMED`; **official performance cohort:** `INELIGIBLE`; **settlement:** `NOT_PERFORMED`; **automation:** `NONE`; **GitHub mutations:** `NONE`. Original user request retained without allocating canonical P-ID. This is a research-only record, not a certified sportsbook probability or promise of low risk.
<!-- END CHAT_LOCAL_DRAFT LOCAL-202611128358B025-G0003 -->


<!-- BEGIN CHAT_LOCAL_DRAFT LOCAL-202611128358B025-G0004 -->
## Research card G0004 — Geelong Venom W vs Perth Lynx W (WNBL27, 13 Nov 2026)

**Status:** `CHAT_LOCAL_RESEARCH_DRAFT / INFORMATION_INCOMPLETE / NOT_REPOSITORY_ISSUED / NOT_PERFORMANCE_ELIGIBLE`.
**Canonical ID:** `NOT_ASSIGNED / PROMPT_4_IMPORT` · **Reference/freeze:** `NOT_RUN` · **Settlement:** `NOT_PERFORMED` · **Owner permission:** `NO_GIT_WRITES`.
**Time of chat-local file creation:** 2026-11-13T18:56:18+11:00. Results/records used are dated at or before 12 November 2026; no live game result was used. Actual first tip and explicit official issuance time `NOT_VERIFIED`; do not retrospectively assert pre-start eligibility.

### A1. Request, authority, competition and contract definitions

| Field | Value |
|---|---|
| Event | Geelong Venom (W) v Perth Lynx (W), WNBL27 Australia, Round 5, regular season; Geelong hosts |
| Official schedule | Friday 13 November 2026, 7:00 PM AEDT (08:00 UTC), Microkeeper Arena, Geelong / North Geelong, Victoria, Australia |
| User aliases | Geelong Venom / Geelong United (2025 former naming); Perth Lynx |
| Requested contracts | Geelong +6.5 points; Perth −6.5 points; over and under 163.5 combined points |
| Endpoint | `FULL_GAME_INCL_OT`, all four 10-minute quarters and all 5-minute overtimes, BK-OT-1 owner convention; no pushes at half-point lines |
| Local record key | `LOCAL-202611128358B025-G0004` (unique, no P-ID allocated) |
| Framework | main branch reference SHA `008cedc4ff469e7a808292aa3667a7bffe22e273` retained; current main controls MDS-2026.11.11-v24.16 / prompt P-2026.11.11-v24.14 / SEL-v4 |
| Issuance | Local diagnostic only; formal `ANALYST_PRIMARY_V1` reference calculation and freeze not performed; read-only GitHub |
| Sources checked | WNBL game preview/fixtures, WNBL results, independent injury inventory, historic H2H; URLs recorded A8 |
| Actual player state | Starting five and active bench not released/verified; WNBL published *expected* rotations, not confirmed lineup |
| No-results exposure | No 13 Nov final/live score used in the research or model; first tip not observed |

### A2. Timing, fixture state and identity

The WNBL's official Nov 13 preview and independently listed club tickets confirm event, venue and 19:00 AEDT start. Official fixture team labels match the request. Earlier 2025 Geelong–Perth meetings are distinct fixtures, not this event. Venue was also called Geelong Arena in stale generic fixture pages; exact-event preview and ticketing call it Microkeeper Arena. This card's publication/retrieval clock is the file creation time; individual page update clocks were not verified. `KNOWN_AT_UNVERIFIED` applies to any source field lacking authentic timestamp certification. Exact starting time as actually played and actual 13 November score state were NOT_VERIFIED. Do not backdate card freeze or issue.

### A3. Dated results and current-season form, roster, workload and H2H

**Geelong 2026/27 regular season (all five games through 12 November, oldest to newest):**

| Date AEDT | Match (venue relative to Geelong) | Geelong | Opponent | Total | Margin GEE |
|---|---|---:|---:|---:|---:|
| 15 Oct | Tasmania Jewels (A) | 90 | 103 | 193 | −13 |
| 24 Oct | Southside Melbourne Flyers (H) | 74 | 69 | 143 | +5 |
| 31 Oct | UC Capitals (H) | 68 | 77 | 145 | −9 |
| 2 Nov | Bendigo Spirit (A) | 77 | 70 | 147 | +7 |
| 5 Nov | Townsville Fire (H) | 67 | 80 | 147 | −13 |

Geelong 2–3; PF=376/5=75.20; PA=399/5=79.80; mean total=775/5=155.00; last-four total mean=145.5; home sample n=3, PF=209/3=69.67, PA=226/3=75.33, total mean 145.00. Over 163.5 = 1/5 (the opening 193). Histories: current-season L5 n=5; L10 n=5, L15 n=5, L20 n=5 **truncated to available current-season sample, not pretending full window**. Cross-season extension to 2025/26 not reconstructed point-in-time, so full L10/15/20 = `HISTORICAL_DATA_UNAVAILABLE:cross-season eligibility and roster comparability not audited`.

**Perth 2026/27 regular season (all four through 12 November):**

| Date AEDT | Match (venue relative to Perth) | Perth | Opponent | Total | Margin PER |
|---|---|---:|---:|---:|---:|
| 17 Oct | Townsville Fire (H) | 86 | 83 | 169 | +3 |
| 24 Oct | Adelaide Lightning (A) | 90 | 82 | 172 | +8 |
| 3 Nov | Townsville Fire (A) | 86 | 99 | 185 | −13 |
| 10 Nov | Bendigo Spirit (H) | 94 | 84 | 178 | +10 |

Perth 3–1; PF=356/4=89.00; PA=348/4=87.00; mean total=704/4=176.00; road sample n=2, PF=176/2=88.00, PA=181/2=90.50, total mean 178.50. Over 163.5 = 4/4. Histories: current-season L5 n=4, L10 n=4, L15 n=4, L20 n=4 (truncated, not full 5/10/15/20); older full-window data not point-in-time admitted.

**H2H (prior 2025/26 season; roster-unstable, descriptive only):** 1 Nov 2025 Geelong 76–77 Perth (153); 11 Nov 2025 Geelong 88–69 Perth (157); 28 Dec 2025 Perth 106–78 Geelong (184). H2H n=3; results not mechanically carried into current team strength because both rosters changed (especially Han Xu's switch to Geelong).

**Current availability (latest retrieved WNBL pregame preview, 13 Nov):** Geelong Bec/Rebecca Cole `OUT`, lower-leg injury, listed return around Round 7; Millicent McCarthy replacement. Geelong expected depth chart PG Maddison Rocci/Lilly Rotunno/Millicent McCarthy; SG Indiah Bowyer/Dakota Crichton/Jasmine King/Cole (OUT); SF Wanglai Zhang/Aleks Connolly/Poppy Stevens; PF Alexandra Sharp/Sara-Rose Smith; C Han Xu/Mackenzie Clinch Hoycard. Perth expected PG Georgia Amoore/Samantha Ashby; SG Alex Ciabattoni/Stephanie Gorman/Kyana Weir; SF Haley Peters/Chloe Hodges/Reece Anticevic; PF Anneli Maley/Brooke Malone; C Teonni Key/Teige Morrell. WNBL's match preview lists no *new* Perth injury; separate injury inventory documents Sami/Samantha Whitcomb's **season-ending knee injury** after Aug 27 club decision. Whitcomb is not in the published active rotation; do not treat official 'no injuries' as proof of her availability. Sources do **not** confirm starting fives, last-minute minutes restrictions, active bench or precise publication timestamps. Geelong's Han Xu has averaged 23.0 PPG to date (league statement); Perth's Georgia Amoore averaged 23.5 PPG in the preceding two games and 6+ assists in each of four. All scoring projections include their existing observed participation; **no duplicate injury or star adjustment**.

**Rest/travel:** Geelong last played home Thursday 5 Nov, eight days prior; Perth last played home Tuesday 10 Nov, three days prior, then travelled WA→Victoria. Neither is on the second night of a back-to-back; there is a plausible rest/travel advantage for Geelong but no WNBL-specific measured effect row was verified, so **scenario-only**, zero numerical direct adjustment. Geelong hosts at home (source verified). Coaches, expected minutes, exact confirmed rotations and same-day statuses `NOT_VERIFIED`.

### A4. Explicit local calculation and limits

**Reference status:** `python -m ml reference tier`, WNBL-specific `BASELINE_LEAGUE_V1`, official `pregame reference/run`, WNBL team-effect regression and frozen reference receipt **NOT_RUN** (no pinned repository checkout/runner with model package available). Accordingly these are **LOCAL_UNCALIBRATED_CONDITIONAL_DIAGNOSTICS, NOT p_card, NOT official probabilities**. `model_p NONE`. No performance qualification is claimed.

Source data: 23 distinct WNBL regular-season completed match results spanning 15 Oct–12 Nov 2026, source dates and scores in `/mnt/data/wnbl_20261113_geelong_perth_diagnostic.py`; zero post-Nov12 inputs. Computed competition sample mean total `164.8696`, raw sample SD total `14.6638`, mean home margin `+2.6087`, raw sample margin SD `14.7886`. These are **small-sample descriptive statistics**, not certified competition parameters; the repo `PARAMETERS.md` has NO dedicated verified WNBL row. WNBA or men's NBL profile values were **not** borrowed as if WNBL.

Choose the following predeclared exploratory calculation (all point quantities, means in 40-minute-plus-OT final-score scale):

- Overall score interaction = 0.5×(own 2026 PF average + opponent 2026 PA average): Geelong `(75.2+87)/2=81.10`; Perth `(89+79.8)/2=84.40`; total `165.50`, margin G−P `−3.30`.
- Venue-conditioned interaction (thin samples n=3 and n=2): Geelong `(69.667+90.50)/2=80.083`; Perth `(88+75.333)/2=81.667`; total `161.75`, margin G−P `−1.583`.
- Blended score means = 50% overall + 50% venue: Geelong `80.592`, Perth `83.033`, total `163.625`, margin G−P `−2.442`. Home edge is already implicit in home/away samples; **no second home bonus added**.
- Total centre shrunk by 20% toward exact-competition sample mean 164.8696: `0.8×163.625 + 0.2×164.8696 = 163.8739`. Keep margin centre `−2.4417`. Final expected team scores `(T+M)/2=80.716` for GEE and `(T−M)/2=83.158` for PER.
- Diagnostic family `(T,M) ~ independent normals` with `μT=163.8739, σT=max(17.0, observed raw 14.664)=17.0`, `μM=−2.4417 (G−P), σM=max(14.0, observed raw 14.789)=14.7886`. 17.0 and 14.0 are **conservative analyst width assumptions**, not fitted WNBL floors. Independence of T and M is assumed for this local model, not demonstrated. Transforming to `G=(T+M)/2`, `P=(T−M)/2` yields one coherent joint normal **approximation** with team SDs each `sqrt((17²+14.7886²)/4)=11.266`; team-score dependence is nonzero (Cov(G,P)=(17²−14.7886²)/4). It is not a calibrated possession model, and normal support permits implausible negative scores (negligible at these means).
- Score and margin SD do not include explicit team-level estimated pace/ORtg/DRtg, referee, injury-minute, or match-specific covariance effects. FIBA four 10-minute quarters/5-minute OT convention included in the endpoint, but the 23 final-score rows cannot isolate regulation and overtime. An explicit validated OT mass is **NOT_ESTIMATED** and this prevents formal issue; the observed final-score moments include any played OT implicitly. No independent source verified the match will or will not need overtime.
- Analytic half-line probability: `Φ((163.5−μT)/σT)` for Under; `1−` for Over. Margin `Φ((−6.5−μM)/σM)` gives PER margin ≥7 (equiv G margin <−6.5), while `1−` gives GEE +6.5. Zero pushes / void in completed matches, under frozen half-point contract convention. Tail normal exact analytic (no finite truncation).
- Executed deterministic 100,000-draw normal simulation **CHECK ONLY**, seed `20261113`, max binomial MC-SE `0.0015811`: sim P(Under 163.5)=`0.49119`, sim P(GEE +6.5)=`0.60622`, consistent within statistical error with analytic. This is a real local numerical execution, **not** a repo ML release, fitted model, official frozen `p_card`, or reliability certification.

| Requested line | Direction | Local conditional p | W/P/L/V | Status |
|---|---|---:|---|---|
| Geelong Venom +6.5 | GEE +6.5 | 0.6081 | 0.6081 / 0 / 0.3919 / 0 | Highest scenario direction, `NOT_CERTIFIED` |
| Perth Lynx −6.5 | PER −6.5 | 0.3919 | 0.3919 / 0 / 0.6081 / 0 | Inverse margin |
| Total 163.5 | OVER | 0.5088 | 0.5088 / 0 / 0.4912 / 0 | Nearly even |
| Total 163.5 | UNDER | 0.4912 | 0.4912 / 0 / 0.5088 / 0 | Nearly even |

**Winner from same normal margin:** P(Geelong win) `Φ(−2.4417/14.7886)≈0.4345`; P(Perth win) ≈`0.5655`. Basketball final score includes OT; no formal unresolved draw is allowed; exact explicit regulation tie mass NOT_ESTIMATED. Model odds for winner are diagnostic only. **Total/side covariance not independently measured**; do not claim exact joint success for a parlay or pair.

**Sensitivity ranges (not confidence intervals):** setting total means to `158.8739 / 163.8739 / 168.8739` while width stays 17 gives P(Under 163.5) approximately `0.6072 / 0.4912 / 0.3760`. Setting margin means G−P to `−7.4417 / −2.4417 / +2.5583` with width 14.7886 gives P(GEE+6.5) `0.4746 / 0.6081 / 0.7299`. These large spreads describe genuine early-season projection instability. No probability has independent prospectively verified calibration.

### A5. Contract ranking, abstention and dependence

**Conditional uncalibrated ordering of supplied rows:** (1) Geelong +6.5 `60.81%`; (2) Over 163.5 `50.88%`; (3) Under 163.5 `49.12%`; (4) Perth −6.5 `39.19%`. Both sides of the half-point spread and total are exact complements of the local model. Because official `p_card` was not frozen and no selection is ≥65%, **official PICKS_V2 NOT_ISSUED; ABSTAIN=YES**. Preferred exploratory direction is **Geelong +6.5**, not certified as a 'safe' bet. The total has no decision-grade separation: opposing recent game styles (GEE last4 145.5; PER n4 176.0) induce highly uncertain pace. No other lines (alternate threshold ladders, quarters, team totals) were enumerated: `PARTIAL_UNIVERSE`. Information list N/A (no frozen reference), adjustment dependence NOT_ESTIMATED. For multi-leg contracts, T/M assumed independent only in scenario diagnostics; not a verified joint, so no claimed de-correlation or exact combination probability.

### A6. League rules and situational context

WNBL uses 40-minute FIBA-length games in four 10-minute quarters. User's supplied game spread/total are final scores including 5-minute overtime periods under BK-OT-1. Empty timeouts, late fouls, overtime, and last-minute substitutions can materially change a 163.5-point total; not individually modeled. No weather effect indoors. Perth crosses time zones and travels WA→Victoria, Geelong has longer rest, but historical measured WNBL travel effect absent. Previous-year H2H shows 153, 157, 184 totals but 2026 lineup changes prevent direct parameter transfer. Han Xu plays her former side; narrative alone not a quantitative effect. Opponent-specific shot-quality/pace/possession data, special-season league calibration, actual starting five and minutes restrictions unavailable in retained evidence.

### A7. Delivery and immutable local custody

Only the current **chat-local mini** is modified, with existing G0001/G0002/G0003 research text retained exactly. This record is not a canonical P-ID, official repository-issued BEGIN CARD, verified freeze, model promotion, settled row, git commit or prediction release. The local calculation file is `wnbl_20261113_geelong_perth_diagnostic.py`, with 23 fully printed historic inputs and complete seed/arithmetic. The local writer cannot enforce the repository agent's lease. This mini's active status does not alter the repository's `CURRENT_STATE.md` (repo active mini remains NONE). No automated follow-up created.

### A8. Evidence source register, provenance and unresolved items

| Evidence | Exact source | Retrieved/read | Publication clock and gap |
|---|---|---|---|
| WNBL official preview and injury/expected rotations | https://www.wnbl.com.au/news/how-to-watch-geelong-v-perth | 13 Nov AEDT pre-event | News page dated 13 Nov; exact timestamp, explicit starting five and published minutes NOT_VERIFIED |
| Official fixture/scores and order | https://schedule.nbl.com.au/wnbl | 13 Nov AEDT pre-event | 23 games identified before 13 Nov only; page includes stale cached snapshots, verified with dated game reports where available |
| Venue/time confirmation | https://www.intix.com.au/event/wnbl-round-5-geelong-venom-vs-perth-lynx/information | 13 Nov AEDT pre-event | Official club ticket listing 19:00 Microkeeper Arena; actual tip phase unknown |
| Official Perth latest game report | https://www.wnbl.com.au/news/lynx-hold-strong-to-overcome-spirit | 13 Nov AEDT pre-event | AAP/league 10 Nov: PER 94–84 Bendigo, Amoore 27 points and six assists; independent player-stat lines differ in scraped boxscores, avoid fitted player input |
| Per-team 2026 historical results | https://schedule.nbl.com.au/wnbl and https://stadiro.com/leagues/basketball/australia/wnbl-women/results/ and https://globalsportsarchive.com/en/basketball/competition/wnbl-2026-2027/80763 | 13 Nov AEDT pre-event | Official WNBL scores corroborated against independent chronological result archives; no odds or predictions used |
| Historic prior-season H2H | https://www.basketball.com.au/news/complete-2025-26-wnbl-season-schedule-and-fixture-list-of-all-92-regular-season-games | 13 Nov AEDT pre-event | Historic 1 Nov, 11 Nov, 28 Dec 2025; relevance downweighted due roster change |
| Whitcomb season injury | https://www.basketball.com.au/news/wnbl-injury-report | 13 Nov AEDT pre-event | Inventory dated 10 Nov, reports club's Aug 27 season out; WNBL official game sheet lists no additional PER injuries; review needed |
| Competition sample raw data | Official 2026 WNBL schedule, 23 finals; reproduced by local script | LOCAL_DIAGNOSTIC | Exact event-by-event score data printed in companion script; no source archive under repository provenance gates |

**Unresolved closures:** exact WNBL event native ID, actual tip-off/issue state, player availability/bench/starting five/medical & publication clocks, permitted source-reader access audit (`ml source-audit` not available), WNBL pace and ORtg/DRtg, independently verified historical L10/L15/L20 across season boundary, possession/covariance/OT regulation-tie data, quantified home/rest/travel changes, opponent adjustment, proper parameter-row `ml reference tier`, frozen `reference` and `pregame run` receipts, representative league baseline with admitted hashes, complete selection universe, formal repository write lease, exact source lineage. These are actual evidence limitations, not assertions the sources do not exist.

### A9. Research completion/verification matrix

| Sport task | Status | Needed for certified issue |
|---|---|---|
| 1 Authority and controls | `READ_ONLY_MAIN`, BASKETBALL sport file, CORE, prompt 1, shared controls and parameter section read | Local repository branch/dirty check, source audit, official writer lease/permissions |
| 2 Identity/timing | Official scheduled 19:00 AEDT match/venue verified; `ACTUAL_TIP: NOT_VERIFIED` | Actual start state, production issue clock, known-at/source replay |
| 3 History and roster | 2026 L5/truncated L10/L15/L20 per side, prior H2H and official expected roster/injury; `INFORMATION_INCOMPLETE` | Genuine full prior-year windows, full field-by-field clearance, live active players/starting five |
| 4 Distribution and baseline | Local arithmetic normal and 100K seeded diagnostic `EXECUTED`; formal WNBL reference, actual OT branch, baseline and official model `NOT_RUN` | Team-strength league-approved baseline/reference, OT scoring branch, evaluated uncertainty/floors, official kit receipts |
| 5 Contracts/ranks | 4 exact requested contract sides computed coherently in local scenario; ABSTAIN=YES; `PARTIAL_UNIVERSE` | Official Picks v2 complete universe/freeze, independently supported p_card |
| 6 Rules/conditions | BK-OT-1 and 40-minute games confirmed in framework; travel/rest described, no fabricated adjustment | Go-live roster, travel and shot-clock details, source timestamps and possession pace |
| 7 Retention | Chat-local G0004 appended/read-back; immutable G0001–G0003 maintained; no git mutation | Official issuer/frozen and published artifacts, settlement done in separate authorized workflow |

**Overall:** `INFORMATION_INCOMPLETE / LOCAL_NUMERICAL_DIAGNOSTIC_ONLY / NOT_REPOSITORY_ISSUED / NOT_PROSPECTIVELY_QUALIFIED / SETTLEMENT_NOT_PERFORMED / CANONICAL_IMPORT_NOT_PERFORMED / GITHUB_WRITES_NONE`. Cannot truthfully claim a calibrated high-confidence betting edge or comprehensive source closure. No scheduled automation exists.
<!-- END CHAT_LOCAL_DRAFT LOCAL-202611128358B025-G0004 -->

<!-- BEGIN CHAT_LOCAL_DRAFT LOCAL-202611128358B025-G0005 -->
## Research card G0005 — Wonju DB Promy v Suwon KT Sonicboom (KBL, 13 November 2026)

**Status:** `CHAT_LOCAL_RESEARCH_DRAFT / INFORMATION_INCOMPLETE / NO_REPOSITORY_ISSUE / NOT_PERFORMANCE_ELIGIBLE / NOT_CALIBRATED`. **Canonical:** `NOT_ASSIGNED / PROMPT_4_IMPORT`. **Settlement:** `NOT_PERFORMED`. **Freeze/reference:** `NOT_RUN` (repository reference/ML modules were not installed/executed). **GitHub writes:** `NONE`. **Local saved time:** `2026-11-13T21:02:36+11:00`.

### A1. Authority, intake, event and exact contracts

- User: *Upcoming Basketball Game: Wonju Promy vs Suwon Sonicboom, Korea KBL; Estimated Game Time Start 13 November 2026 9:00 PM AEDT, delays possible; Promy −5.5; Sonicboom +5.5; total Over/Under 179.5 Points.* Exact sides are kept unchanged.
- Home: Wonju DB Promy (aliases Wonju Dongbu Promy, 원주 DB 프로미); away Suwon KT Sonicboom (수원 KT 소닉붐). 2026–27 KBL regular season; court Wonju DB Promy Arena, Wonju. Native provider match `S49G01N66` (StatGG); provider TheSportsDB `2583495`. One event (not a doubleheader). Official schedule 2026-11-13 19:00 Asia/Seoul / 10:00 UTC / **21:00 Australia/Melbourne AEDT**.
- Official schedule https://www.kbl.or.kr/match/schedule and https://promy.kbl.or.kr/match/schedule ; independent confirmation Yonhap 2026-11-13 06:15 KST https://www.yna.co.kr/view/AKR20261112101800007 ; provider https://statgg.com/en/kbl/matches/S49G01N66 . Actual tip-off `NOT_VERIFIED` at research time.
- Repository read-only `main` authority previous pinned `008cedc4ff469e7a808292aa3667a7bffe22e273`, `MDS-2026.11.11-v24.16`, `P-2026.11.11-v24.14`, `SCV-v13`, `SEL-v4`, `mini-log-10`; sport prompt `research/prompts/1_sports/BASKETBALL.md` and `CORE`, `RULES_REFERENCE`, `PARAMETERS`, `COMMON_OPERATING_PROTOCOL`, `1_GAME_CARD` reviewed during chat. No repository local working-tree HEAD, writer lease, execution/freeze/commit verification possible. This is a chat-local draft under user's explicit NO PUSH rule.
- Timing: owner request ~20:54 AEDT (seconds unknown); official scheduled time 21:00 AEDT; local research & save `2026-11-13T21:02:36+11:00`. Publication of the late lineup/first-play state not independently verified; therefore `PREGAME_ISSUE_NOT_CERTIFIED`. Any research issued after the actual start is not a prospective pregame forecast.
- Endpoint on all four lines `FULL_GAME_INCL_OT` per BK-OT-1 framework. No integer threshold or push on ±5.5 and 179.5; W+L=1 conditional on a completed game; postponed/abandoned settlement is unverified separately. Match winner not user-provided; an illustrative continuous margin proxy below is informational only.

### A2. Identity, duplication and fixture/state check

No alias match with local G0001 tennis Orléans, G0002 Kazakhstan hockey, G0003 Stockholm tennis or G0004 WNBL basketball. Prior Wonju–Suwon meeting on **2026-10-23** is a different game, `KT 95–102 DB` (197 combined points, Wonju +7). This event is not yet confirmed underway or complete; no current game outcome viewed at intake. Repository Combined Log not exhaustively duplicated-scanned in this chat; `CANONICAL_DUPLICATE_CHECK_INCOMPLETE`. The mini retains a new, noncanonical local key G0005.

### A3. Dated sporting form, pace, injuries, player roles and source ledger

**Pre-event 2026–27 KBL season through 12 Nov, n=13 each (StatGG and independent Korean KBL match summary):**

| Statistic | Wonju DB | Suwon KT |
|---|---:|---:|
| Record | 7–6 | 6–7 |
| Rank | 4 | 6 (rank provider discrepancy: StatGG displays 5; league/press 6) |
| Points for / against per game | 90.1 / 89.3 | 85.0 / 86.5 |
| Offensive / defensive rating | 113.8 / 113.1 | 111.8 / 116.7 |
| Reported pace proxy | 77.2 | 72.7 |
| Home/away sample | Wonju home 3–2 | KT away 3–4 |
| 3-point percentage | 34.6% | 31.3% |
| Assists, turnovers per game | 18.4 / 10.3 | 16.3 / 10.6 |

**Verified recent five completed games, newest first (as of 2026-11-12, n=5 on both sides), teams' scores written as own points–opponent points:**

| Date | Wonju DB result | Date | Suwon KT result |
|---|---|---|---|
| Nov 08 | Lost at Seoul SK, **65–81** | Nov 09 | Lost at Seoul Samsung, **78–85** |
| Nov 07 | Beat Seoul Samsung, **84–76** | Nov 07 | Beat Daegu KOGAS, **92–81** |
| Nov 01 | Beat Changwon LG, **104–98** | Nov 01 | Beat Goyang Sono, **103–96** |
| Oct 31 | Lost at KCC, **74–90** | Oct 31 | Beat Anyang, **92–90** |
| Oct 28 | Lost at Daegu, **90–95** | Oct 25 | Lost at Seoul SK, **79–90** |
| L5 | 2–3; for **83.4**, against **88.0**, total **171.4**, SD not robustly estimated | L5 | 3–2; for **88.8**, against **88.4**, total **177.2** |

**Longer windows:** Wonju L6 supported October 25 Anyang 95–93; L7 October 23 at Suwon KT 102–95; Oct 19 home KOGAS 104–78; Oct 17 vs Samsung 95–92? 2026 match result displayed as Samsung 95, DB 92 so DB lost 92–95; Oct 12 at Mobis 89–99. Current-season Wonju L10 from dated score records has partial support but needs independent crosscheck for all rows; Suwon L6–L10 and both sides' L15/L20 exact dated sequences **NOT_FULLY_VERIFIED**. Neither unused offseason nor previous-season matches imputed into league windows. Formal historical source pack and independent field-level provenance receipts `NOT_RUN`.

**Health, lineup and roles:**

- **Wonju Henry Ellenson**: Korean specialist *Jumpball* article published 2026-11-13 10:45 KST reports return for this game, first appearance since October 19, after **seven games absent** with headaches; season six games, 24.5 points/8.2 rebounds in 30.3 minutes. His *net* scoring effect is not 24.5 points added to the team: replacement usage may be displaced. Starting status, minutes restriction and official active list **NOT_VERIFIED**. Rayshaun Hammonds 21.8 PPG, Ethan Albano 20.1 PPG and 7.2 APG, and temporary center Alan Williams (last-game reference) are known contributors. Some provider roster notes stale, so current official activation matters. Wonju Jeong Ho-young ACL season-ending per secondary tracker; Kang Sang-jae status unclear/questionable; official active bench not verified.
- **Suwon KT**: Kim Sun-hyung (G, post-appendix rupture/peritonitis surgery) **OUT**, Ha Yun-gi (C, bone bruise/rehab) **OUT**, Miguel Ojon/Oczon (G, Nov 6 appendicitis surgery) **OUT** on last checked third-party report Nov 12 KST, Jeong Chang-young (F) **QUESTIONABLE** after Nov 9 injury. Paris Bass (StatGG/RealGM current 28.2 PPG, ~10.2 RPG, 5 APG) is key load-bearing scorer; Trey Porter active in recent records. **These absences are not new to all 13 season games; no direct points penalty was double-counted.** Sources: https://www.dailyil.com/ko/briefing/2026-11-13_KBL/ , https://www.dailyil.com/en/league/kbl/ and https://www.jumpball.co.kr/news/newsview.php?ncode=1065577530368244 . Final official starting fives, active bench, restrictions `NOT_VERIFIED`; third-party probable lineups cannot certify starters.
- Coach Lee Kyu-sup (Wonju), Moon Kyung-eun (Suwon). Wonju last played Nov 8 (five days rest), KT Nov 9 (four days rest); **no back-to-back on the requested date**. Wonju home-court advantage considered scenario only, not borrowed from NBA measured effects. Indoor venue, no weather adjustment.

**Source/capture receipt** (search executed in current chat, pre-result; retrieval clocks only known at rough 2026-11-13T20:54–20:59+11:00):

1. KBL official https://www.kbl.or.kr/match/schedule : 13 Nov 19:00 KST DB–KT at Wonju; Korean news Yonhap https://www.yna.co.kr/view/AKR20261112101800007 corroborates.
2. StatGG https://statgg.com/en/kbl/matches/S49G01N66 : season record, ratings, pace, FG/3P, 10/23 head-to-head; same-data aggregator copies do not count independent collector audits.
3. https://abasketballreport.com/predictions/head-to-head/2026-11-13/south-korea/kbl/wonju-db-promy/suwon-kt-sonicboom/NzAyNjMtNzAyNjI%3D : dated recent played scores; used historical results ONLY, not predictions. Cross-check against https://en.sportsand.me/basketball/south-korea-kbl?tab=calendar and KBL site where possible.
4. https://www.jumpball.co.kr/news/newsview.php?ncode=1065577530368244 : dated Korean specialist Ellenson return and team notes (published 10:45:39 KST 13 November); secondary absence list https://www.dailyil.com/ko/briefing/2026-11-13_KBL/ . These are not official confirmed starters.
5. https://www.sofascore.com/basketball/match/suwon-kt-sonicboom-wonju-db-promy/DAabsWAab : fixture 2026-11-13 10:00 UTC; duplicate corroboration.

**Access/lineage limitations:** Repository `ml source-audit` was NOT_RUN in this chat; source URLs were accessed by ordinary web tool, not via repository CLAUDE_AGENT gate. Source-lineage independent audit `NOT_VERIFIED`; exact local read/retrieval timestamp per URL not recorded. The occurrence of a URL does not certify an access gate or fact-level independence. No postgame score, betting price or externally forecast probability used for numeric adjustments.

### A4. Coherent illustrative scoring distribution; arithmetic and source limits

**Reference stage:** `NOT_RUN` — no verified runnable repository `ml.reference tier`, `reference run`, pregame freeze or `BASELINE_LEAGUE_V1` receipt. KBL appears in historical development `PARAMETERS` Part A (`Basketball/KBL` mean total 159.39, residual margin SD 12.61, residual total SD 16.82), but that older cross-season population conflicts with *2026–27 actual* team scoring and lacks online re-establishment for this league season; **not substituted for current league average**. Competitive 2026/27 KBL league-wide baseline source/sample `NOT_ESTIMATED`. KBL benchmark widths not certified for this current league.

**Exploratory scenario (not a promoted, frozen or calibrated card model):**

- Season cross-means: home = (Wonju PF 90.1 + KT PA 86.5)/2 = **88.300**; away = (KT PF 85.0 + Wonju PA 89.3)/2 = **87.150**; joint centre 175.450, signed margin 1.150.
- Recent L5 cross-means: home=(83.4+88.4)/2=**85.900**, away=(88.8+88.0)/2=**88.400**, joint total 174.300, signed margin −2.500.
- Pace/efficiency *proxy*, not opponent-validated possessions: shared possession-rate proxy=(77.2+72.7)/2=**74.95**. Home attack=(113.8+116.7)/2×74.95/100≈**86.380**; away=(111.8+113.1)/2×74.95/100≈**84.281**; total ≈170.661. Rating/pace definitions and opponent adjustments remain not independently verified; do not infer effective possessions precision.
- **Prespecified subjective blend:** .55 season + .25 L5 + .20 pace proxy by team yields Wonju **87.316**, KT **86.889** (total ≈174.205). These weights are exploratory only, have NO KBL crossvalidated justification and must not be represented as official fitted parameters.
- Home venue margin *scenario only* +0.65 Wonju and −0.65 KT; total conserved. Ellenson return net *scenario* +2.5 to Wonju offense, with alternatives 0 and +6 (NOT learned effect size; no double counting of the 24.5 PPG). KT injuries assumed embedded in season/L5 inputs, not subtracted anew. This makes centres **Wonju 90.466, Suwon 86.239**, signed Wonju margin **+4.227**, combined total **176.705**. Central illustrative score roughly **90–86**.
- Independent normals for final total and signed final margin; SD total **18.4**, SD margin **14.5**, purposefully wider than historical KBL residual floors because sparse known-at availability. \(T\sim N(176.705,18.4^2),\ M\sim N(4.227,14.5^2)\). Cov(T,M) provisionally 0; yields joint team scores `(T+M)/2`, `(T-M)/2`. However integer support, KBL 5-minute OT conditional branch, covariance and scoring tails are not separately calibrated: **approximate full-game incl-OT proxy only**, not an exact KBL distribution. No moneyline draw/OT explicit certified decomposition or exact joint betting combinations. The scenario has no Monte Carlo; analytic normal CDF was actually executed in `/mnt/data/kbl_20261113_wonju_suwon_diagnostic.py`.
- For half-point lines without push on completed match, probability is `Phi((margin−5.5)/14.5)` for Wonju −5.5, its complement for KT +5.5, and `Phi((179.5−total)/18.4)` for Under 179.5, complement Over. All rounded to one decimal percentage point in chat; no manufactured empirical confidence bounds.

### A5. All exact supplied sides, their risk and ranking

| Contract (completed game, includes OT) | W / P / L / V conditional local proxy | Scenario p | Relative order | Eligibility |
|---|---|---:|---:|---|
| **Under 179.5** | 0.56037 / 0 / 0.43963 / 0 | **56.0%** | 1 | `LOCAL_DIAGNOSTIC`, NOT p_card |
| **Suwon KT +5.5** | 0.53497 / 0 / 0.46503 / 0 | **53.5%** | 2 | `LOCAL_DIAGNOSTIC`, NOT p_card |
| **Wonju DB −5.5** | 0.46503 / 0 / 0.53497 / 0 | **46.5%** | 3 | `LOCAL_DIAGNOSTIC`, NOT p_card |
| **Over 179.5** | 0.43963 / 0 / 0.56037 / 0 | **44.0%** | 4 | `LOCAL_DIAGNOSTIC`, NOT p_card |

- Conditional Wonju full-game win approximation 61.5%; KT 38.5% (not supplied, informational, regulation integer ties/OT unresolved), so **Wonju favoured to win, but not confidently to cover −5.5**. Correct spread/total complementary pairs each sum to 1 within rounding.
- The two metrics total and margin share a model assumption; a defensible event-level joint OT/covariance distribution was not computed, so no exact probability for two selections simultaneously. By independent proxy only one can compute a product, but **do not do so** without empirical dependence and OT treatment.
- `MOST_LIKELY_LIST` exploratory diagnostics 1 Under, 2 KT +5.5, 3 DB −5.5, 4 Over; `INFORMATION_LIST: NONE_VERIFIED` (no frozen reference/ledger comparison); `ABSTAIN: YES` as all scenarios below 65% and material lineup/OT information incomplete. `PARTIAL_UNIVERSE`: only four supplied directions assessed; no unsupported inflated alternate ladders.
- **Directional lean:** Under 179.5, **LOW confidence** and no strong selection. This is an estimate conditional on declared centres and volatility, not a probability with demonstrated predictive reliability.

### A6. Sensitivities, home/away and playing conditions

With all other scenario assumptions held fixed, Ellenson *net* effect W=0 vs +2.5 vs +6 changes illustrative Under 179.5 from **61.3%** → **56.0%** → **48.5%**; KT +5.5 from **60.3%** → **53.5%** → **43.9%**. This is a model-input sensitivity, not a valid statistical interval or lineup outcome forecast. A five-point total-centre error alone shifts Under from about 66% (−5) to 45% (+5); thus no safe edge asserted. Form L5 ≈171.4 Wonju own games and 177.2 KT own games; single prior H2H total **197** on Oct 23 is a warning of an upside tail, not a reason to force an Over. Home 3–2 vs away 3–4 samples weak. Rest: 5 days DB, 4 days KT. Official KBL 40-minute regulation plus 5-minute overtime and BK-OT-1 incl every overtime. Formal league-specific tie probability and explicit extension were not reproduced; scoring centre includes season final scores as a practical proxy, not exact endpoint definition closure.

### A7. Local model/receipt/prospective status

- Executed: `python /mnt/data/kbl_20261113_wonju_suwon_diagnostic.py` local arithmetic and Gaussian CDF; printed centres and all contract scenario probabilities. Execution from chat-local runtime; not from repository pinned checkout; no `ml` module tested, no reference or freeze.
- `model_p NONE`, `reference_p NONE`, `baseline_p NONE`, `published/card p NOT_ESTIMATED`. Printed local percentages are expressly **shadow-style exploratory diagnostics**, never officially issued `ANALYST_PRIMARY_V1` results. No 100K simulation or posterior claimed.
- `DATA_CUTOFF`: prior completions through 2026-11-12, 2026-11-13 preview published 10:45 KST; no match-result exposure at drafting. `REQUEST_TIME`: approx 20:54 AEDT, `LOCAL_WRITE`: `2026-11-13T21:02:36+11:00`, `ACTUAL_GAME_START`: NOT_VERIFIED; `CLEAN_PRE_START_ISSUE`: NOT_CERTIFIED, even when saved before scheduled 21:00.

### A8. Outstanding evidence, source access and next actions

| Field | State | Next evidence needed | Owner/actor | Due and last attempt | Automation |
|---|---|---|---|---|---|
| Actual tip-off/final lineup | UNRESOLVED | Official KBL game sheet starting five, bench, active imports and real start | Future authorized repository writer | At actual pregame lineup release; last search ~20:59 AEDT 13 Nov 2026 | NONE |
| Ellenson return/minutes | Expected return in Jumpball; exact role UNVERIFIED | Official attendance/minutes/coach confirmation before opening tip | Source researcher | Pre-start last checked Korean Jumpball same day | NONE |
| KT four statuses | 3 OUT/1 questionable in third-party report | Official roster confirmation, Jeong Chang-young disposition | Source researcher | Latest secondary update Nov 12 22:30 KST; official no confirmation | NONE |
| True L10/L15/L20, venue/possessions | INCOMPLETE | Full dated 2026 season and previous-season game results under same definition, missing rows and crosscheck | Source researcher | Recent L5 verified Nov 13 pregame, no complete longer cohort | NONE |
| KBL baseline / OT and writer freeze | NOT_RUN | Authorized repo reference tier, KBL league-only baseline, explicit overtime score distribution, source audit, Git checkout/write lease and receipts | Repository agent | No repository execution attempted; NOT_SCHEDULED | NONE |

**Reader/access:** Browser search outputs gave content; a failed direct page open elsewhere is not proof source is disallowed. Exact repository source-audit checks cannot be claimed. Repo remains strictly read-only under owner instruction; a chat-local artifact is not an official active mini in repo. The no-Git-push constraint is absolute.

### A9. Research-completion matrix and disposition

| Step | Completed evidence | Missing prerequisite / status |
|---|---|---|
| 1 authority | Main basketball prompt, core/protocol/relevant rules reviewed, previous mini read | No actual working-tree diff, writer lease, source-audit receipt; `INFORMATION_INCOMPLETE` |
| 2 identity/timing | KBL schedule, arena, 19 KST=21 AEDT, KT-DB H2H distinguished, local uniqueness checked | Actual tip-off and exhaustive canonical duplicate lookup `NOT_VERIFIED` |
| 3 performance/roster | Season stats, actual L5 scores both, prior H2H, Ellenson return, KT injuries, rest and coaches | Complete L10/L15/L20, verified starting lineups/bench, independent collector access checks |
| 4 family/math | Executed local analytic normal, all centres/SD/assumptions disclosed | Certified KBL tier, reference/baseline, exact overtime score states and covariance `NOT_ESTIMATED` |
| 5 requested contracts | All four sides assessed and sum-to-one sanity checks; ranking and abstention declared | Official selection/PICKS_V2 + frozen model rows `NOT_RUN` |
| 6 playing rules | Home venue, 40-minute basketball BK-OT-1 endpoint | Exact competition overtime distribution and lineup-driven usage/pace uncertain |
| 7 retention | Appended chat-local G0005 with prior four cores byte intact, intake and footer aligned, SHA/readback | Authorized formal issue/import/settlement intentionally `NOT_PERFORMED` |

**Overall:** `LOCAL_NUMERICAL_DIAGNOSTIC_ONLY / INFORMATION_INCOMPLETE / ABSTAIN_TRUE / NOT_ISSUED / NOT_PROSPECTIVELY_QUALIFIED / NO_GIT_PUSH / NO_CANONICAL_IMPORT`.
<!-- END CHAT_LOCAL_DRAFT LOCAL-202611128358B025-G0005 -->

# RUNNING FOOTER

<!-- BEGIN FOOTER -->
| Field | Value |
|---|---|
| Last local event key / next local event key | `LOCAL-202611128358B025-G0005` / `LOCAL-202611128358B025-G0006` |
| New canonical IDs assigned | `NONE`; assignment only in `PROMPT_4_IMPORT` |
| Repository next-ID snapshot | `P-639` (unallocated) |
| New cards / numeric / qualitative / NO_FORECAST | `0 formally issued / 5 local diagnostic drafts / 0 / 0` |
| Pending events / unresolved evidence records | `5 research drafts / all prior G0001–G0004 outstanding fields retained; G0005: confirmed starting five, full L10/L15/L20, KBL-specific OT/reference, access audit, actual tip and official freeze` |
| Local mini status / import status | `ACTIVE_CHAT_LOCAL / NOT_PUBLISHED / NOT_IMPORTED / NOT_REPOSITORY_ISSUED` |
| GitHub writes performed | `NO` |
| Repository current-state changed | `NO` |
| Mini last updated | `2026-11-13T21:02:36+11:00` (G0005 research-only; G0001–G0004 unchanged) |
<!-- END FOOTER -->
