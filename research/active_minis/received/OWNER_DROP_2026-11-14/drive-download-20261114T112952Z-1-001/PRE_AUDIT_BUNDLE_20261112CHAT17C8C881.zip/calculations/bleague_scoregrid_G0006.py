"""Illustrative sports-only KBT/Saga B.PREMIER hypothetical sensitivity grid.
NOT calibrated; assumptions do not substitute for a qualified source or official reference.
Known-at source: official B.LEAGUE and both clubs' RESULTS through 2026-11-12 JST.
Neither model weight nor scenario weight is empirically estimated.
"""
import math
import numpy as np

# Observed scored/allowed pairs, newest first, from pre-event official team histories
K=[('2026-11-11','Shimane',74,95),('2026-11-09','Altiri Chiba',76,85),('2026-11-06','Shiga',75,81),('2026-11-01','Yokohama BC',66,77),('2026-10-31','Yokohama BC',65,75),('2026-10-26','Utsunomiya',92,89),('2026-10-24','Sendai',82,93),('2026-10-21','Osaka',101,67),('2026-10-19','Shimane',69,80),('2026-10-16','Ibaraki',74,85)]
S=[('2026-11-08','Chiba Jets',103,111),('2026-11-01','Mikawa',78,84),('2026-10-31','Mikawa',83,100),('2026-10-26','Alvark Tokyo',88,112),('2026-10-21','Nagasaki',66,84),('2026-10-18','Kyoto',70,115),('2026-10-16','Hokkaido',90,109),('2026-10-12','Gunma',61,72),('2026-10-10','Kobe',84,77),('2026-10-08','Alvark Tokyo',74,90)]
assert len(K)==len(S)==10
for name, r in [('Kawasaki',K),('Saga',S)]:
 for n in [5,10]:
  pts=sum(v[2] for v in r[:n]); opp=sum(v[3] for v in r[:n]); over=sum((v[2]+v[3])>=170 for v in r[:n]); covers=sum((v[2]-v[3])>=10 for v in r[:n])
  print(name,'L',n,'PF',pts/n,'PA',opp/n,'T',(pts+opp)/n,'Over169.5',over,'wonBy10+',covers)

# Reconstructed from official standings and season points: K 4-12 (1256 PF, 1355 PA), Saga 1-13 (1095 PF, 1333 PA).
print('Season K',1256/16,1355/16,'S',1095/14,1333/14)
print('Season naive cross',((1256/16)+(1333/14))/2,((1095/14)+(1355/16))/2)

A=np.arange(0,241,dtype=float)[:,None]
B=np.arange(0,241,dtype=float)[None,:]
t=A+B;m=A-B
sd_t,sd_m=18.5,14.1 # FIBA40-family width floor +10% as development-only analogy, not a B.PREMIER fitted SD
# Construct 2D joint distribution over regulation integer scores, tails outside grid not explicitly priced.
scenarios=[('slow',0.25,81.0,76.0),('base',0.50,87.0,80.0),('fast',0.25,96.0,88.0)]
summary=[]; ensemble=np.zeros((len(A),len(B.T)))
for name,w,k,s in scenarios:
 p=np.exp(-.5*((t-(k+s))/sd_t)**2-.5*((m-(k-s))/sd_m)**2)
 p/=p.sum()
 # Operational assumption: one 5-minute extra period on regulation tie, +16 points (8:8); break tie with +/-1 scoreboard point.
 # Mean extra total +17 points on a tie, in two equiprobable mirrored final score branches.
 q=p.copy()
 tie=(A==B)
 td=float(q[tie].sum())
 # Two representative OT score allocations: +9/+8 or +8/+9, using integer final-score cells.
 ot_mass=float(q[tie].sum())
 ff=p.copy();ff[tie]=0
 for idx in range(len(A)):
  pp=float(p[idx,idx])
  if pp<1e-30:continue
  if idx+9<len(A):
   ff[idx+9,idx+8]+=0.5*pp
   ff[idx+8,idx+9]+=0.5*pp
  else: raise RuntimeError('material tail OT cell')
 assert abs(ff.sum()-1)<1e-12
 over=float(ff[(t>=170)].sum()); under=1-over
 minus=float(ff[(m>=10)].sum()); plus=1-minus
 k_win=float(ff[(m>0)].sum()); s_win=1-k_win
 mean_k=float((ff*A).sum());mean_s=float((ff*B).sum())
 joint_fail=float(ff[((m>=10)&(t>=170))].sum()) # both +9.5 and under169.5 lose
 print(name,'weight',w,'mu',k,s,'final',mean_k,mean_s,'ot',ot_mass,'plus',plus,'under',under,'minus',minus,'Kwin',k_win,'jointLose',joint_fail)
 summary.append((w,plus,under,minus,over,k_win,s_win,mean_k,mean_s,ot_mass,joint_fail))
summary=np.array(summary)
a=(summary[:,0,None]*summary[:,1:]).sum(axis=0)
print('mixture plus under minus over Kwin Swin K S OT jointLose',*(round(v,7) for v in a))
print('Complement checks',a[0]+a[2],a[1]+a[3],a[4]+a[5])
