"""Read-only reproducible research diagnostic for local mini G0002.
Transcribed 2026-27 official Pro Hokei Ligasy schedules known before 12 November.
NOT a certified/pre-start forecast; no bookmaker info or market odds.
"""
from datetime import datetime
import math
from collections import Counter
from scipy.stats import poisson, skellam
# date, opponent, GF, GA, note; OT/SO scores displayed as league final, not pure regulation
TOR=[
('2026-09-02','Almaty',9,0,''),('2026-09-03','Almaty',3,2,''),
('2026-09-06','Arlan',2,3,''),('2026-09-07','Arlan',4,3,'OT'),
('2026-09-10','Saryarqa',0,2,''),('2026-09-11','Saryarqa',3,2,'SO'),
('2026-09-16','Qulager',3,2,'OT'),('2026-09-17','Qulager',6,3,''),
('2026-09-20','Gornyak',4,3,''),('2026-09-21','Gornyak',1,2,''),
('2026-09-27','Aqtobe',9,1,''),('2026-09-28','Aqtobe',6,2,''),
('2026-10-01','Beibarys',4,3,''),('2026-10-02','Beibarys',9,2,''),
('2026-10-06','Nomad',2,3,'OT'),('2026-10-07','Nomad',2,3,'SO'),
('2026-10-11','Ertis',13,0,''),('2026-10-12','Ertis',8,0,''),
('2026-10-15','Ertis',9,2,''),('2026-10-16','Ertis',12,1,''),
('2026-10-19','Almaty',9,1,''),('2026-10-20','Almaty',4,0,''),
('2026-10-25','Aqtobe',4,2,''),('2026-10-26','Aqtobe',3,1,''),
('2026-10-29','Nomad',6,3,''),('2026-10-30','Nomad',3,0,''),
]
ARL=[
('2026-09-02','Gornyak',3,1,''),('2026-09-03','Gornyak',1,3,''),
('2026-09-06','Torpedo',3,2,''),('2026-09-07','Torpedo',3,4,'OT'),
('2026-09-11','Aqtobe',5,2,''),('2026-09-12','Aqtobe',5,4,''),
('2026-09-15','Beibarys',3,1,''),('2026-09-16','Beibarys',1,0,''),
('2026-09-22','Saryarqa',5,0,'TECH_AWARDED'),
('2026-09-23','Saryarqa',2,5,''),
('2026-09-27','Ertis',11,2,''),('2026-09-28','Ertis',5,3,''),
('2026-10-02','Almaty',1,2,''),('2026-10-03','Almaty',3,2,''),
('2026-10-06','Qulager',4,3,''),('2026-10-07','Qulager',4,3,''),
('2026-10-10','Nomad',3,2,'OT'),('2026-10-11','Nomad',2,4,''),
('2026-10-14','Saryarqa',1,4,''),('2026-10-15','Saryarqa',4,3,'SO'),
('2026-10-20','Ertis',5,1,''),('2026-10-21','Ertis',9,2,''),
('2026-10-25','Almaty',3,0,''),('2026-10-26','Almaty',4,3,''),
('2026-10-29','Gornyak',3,2,''),('2026-10-30','Gornyak',4,0,''),
]
def stats(data,n):
  x=[z for z in data if z[4] != 'TECH_AWARDED'][-n:]
  m=len(x)
  return dict(n=m,GF=sum(z[2] for z in x),GA=sum(z[3] for z in x),GFavg=round(sum(z[2] for z in x)/m,3),GAavg=round(sum(z[3] for z in x)/m,3),Tavg=round(sum(z[2]+z[3] for z in x)/m,3),Under65=sum((z[2]+z[3])<=6 for z in x),Over65=sum((z[2]+z[3])>=7 for z in x),W=sum(z[2]>z[3] for z in x),Opponents=Counter(z[1] for z in x))
for name,data in [('TORPEDO',TOR),('ARLAN',ARL)]:
  for n in (5,10,15,20,99):
    s=stats(data,n)
    print(name,'L'+str(n),{k:v for k,v in s.items() if k!='Opponents'},'opponents',dict(s['Opponents']))
  h=[z for z in data if z[1] not in ('Ertis','Aqtobe','Almaty') and z[4]!='TECH_AWARDED']
  print(name,'EXCLUDE_ERTIS_AQTOBE_ALMATY', {k:v for k,v in stats(h,99).items() if k!='Opponents'})
# H2H descending; 10 list available from specialist. Cup games separate from regular season.
h2h=[('2026-09-07',3,4,'OT'),('2026-09-06',3,2,''),('2026-08-14',2,3,'CUP'),('2026-02-15',2,5,''),('2026-02-14',1,3,''),('2025-12-06',2,1,''),('2025-12-05',1,4,''),('2025-09-08',0,9,''),('2025-09-07',4,3,'SO'),('2025-08-28',2,3,'CUP')]
print('H2H_10',dict(n=10,under65=sum(a+b<=6 for _,a,b,_ in h2h),totalavg=round(sum(a+b for _,a,b,_ in h2h)/10,3)))
# Low/base/high subjective sensitivity, NOT a formal calibrated p_card.
# Scenarios are alternative hypothetical latent regulation scoring intensities. Do not use OT as automatic extra unit.
scenarios=[('Low-goal',0.25,2.9,2.2),('Base',0.50,3.25,2.35),('High-goal',0.25,3.6,2.65)]
results={}
for label,w,a,b in scenarios:
  u=poisson.cdf(6,a+b) # independent Poisson total for regulation endpoint
  h=skellam.cdf(1,a,b) # Arlan +1.5 regulation: Torpedo-Arlan <= 1
  homewin_reg=1-skellam.cdf(0,a,b)
  tied=skellam.pmf(0,a,b)
  # regulation tie goes to either team in full game, but still plus1.5 and under 6.5 may change depending on OT/settlement
  print(label,dict(weight=w,lambda_t=a,lambda_a=b,mu=a+b,P_under65_reg=round(u,6),P_arlan_plus15_reg=round(h,6),P_torpedo_minus15_reg=round(1-h,6),P_reg_homewin=round(homewin_reg,6),P_reg_draw=round(tied,6)))
  for k,v in [('under65',u),('arlan_plus15',h),('home_reg_win',homewin_reg),('reg_draw',tied)]:results[k]=results.get(k,0)+w*v
print('MIXTURE_DIAGNOSTIC',results)
# Concurrent loss: Torpedo regulation margin >=2 AND regulation total>=7 (both Arlan+1.5 and Under6.5 lose).
loss_both=0
for _,w,lt,la in scenarios:
  xx=0
  for a in range(35):
    for b in range(35):
      if a-b>=2 and a+b>=7:xx+=poisson.pmf(a,lt)*poisson.pmf(b,la)
  loss_both+=w*xx
print('BOTH_UNDER_AND_ARLAN_PLUS15_LOSE',loss_both)
league_games=(26+26+25+26+26+24+26+26+25+24)/2
league_goals=sum([138,92,102,108,90,87,66,69,48,31])
print('LEAGUE_BASELINE',dict(games=league_games,goals=league_goals,mean=league_goals/league_games,under65_reg_Pois=poisson.cdf(6,league_goals/league_games)))
fullunder=0
for label,w,lt,la in scenarios:
  p33=poisson.pmf(3,lt)*poisson.pmf(3,la)
  underfull=poisson.cdf(6,lt+la)-p33
  fullunder+=w*underfull
  print(label,'P_reg_3_3',p33,'P_full_under65_diag',underfull)
print('MIXTURE_DIAGNOSTIC_FULL_U65_WITH_SINGLE_OT_SO_GOAL',fullunder)
