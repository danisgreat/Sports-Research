#!/usr/bin/env python3
"""Chat-only G0007: an explicitly uncalibrated, assumed independent-Poisson sensitivity grid.
Do not use as an independently qualified forecast, official ml reference, or receipt.
Historical sample goals include possible OT/SO deciding goals; the regulation parameters
below are judgmental scenarios, not directly fitted shot/goaltending expectations.
"""
from math import exp, factorial
from pprint import pprint

EVENT = 'LOCAL-20261112CHAT17C8C881-G0007'
SCENARIOS = [
    {'label':'lower scoring', 'weight':.25, 'motor_reg_mean':3.30, 'liberec_reg_mean':2.10},
    {'label':'central',       'weight':.50, 'motor_reg_mean':3.75, 'liberec_reg_mean':2.30},
    {'label':'higher scoring','weight':.25, 'motor_reg_mean':4.25, 'liberec_reg_mean':2.60},
]

def poisson(mu,max_goals=24):
    return [exp(-mu)*mu**k/factorial(k) for k in range(max_goals+1)]

def evaluate(s):
    a=poisson(s['motor_reg_mean']); b=poisson(s['liberec_reg_mean'])
    d={'p_motor_minus_1_5':0,'p_liberec_plus_1_5':0,'p_over_5_5':0,
       'p_under_5_5':0,'p_reg_tie':0,'p_motor_reg_win':0,
       'p_motor_full_win_equal_ot_assumption':0,'both_over_and_lib_cushion_fail':0,
       'normalization':0}
    for x,pa in enumerate(a):
        for y,pb in enumerate(b):
            p=pa*pb
            d['normalization']+=p
            minus=x-y>=2
            over=x+y>=6   # +1 OT/SO from a tie cannot cross this 5.5 line
            d['p_motor_minus_1_5']+=p*minus
            d['p_liberec_plus_1_5']+=p*(not minus)
            d['p_over_5_5']+=p*over
            d['p_under_5_5']+=p*(not over)
            d['p_reg_tie']+=p*(x==y)
            d['p_motor_reg_win']+=p*(x>y)
            d['p_motor_full_win_equal_ot_assumption']+=p*((x>y)+.5*(x==y))
            d['both_over_and_lib_cushion_fail']+=p*((not over) and minus)
    d.update({'E_motor_reg_goals':s['motor_reg_mean'],
              'E_liberec_reg_goals':s['liberec_reg_mean'],
              'E_reg_total':s['motor_reg_mean']+s['liberec_reg_mean']})
    return d

if __name__=='__main__':
    totals={}
    for s in SCENARIOS:
        d=evaluate(s)
        print(s['label'], 'assumed mu',s['motor_reg_mean'],s['liberec_reg_mean'])
        pprint({k:round(v,6) for k,v in d.items()})
        for k,v in d.items(): totals[k]=totals.get(k,0)+s['weight']*v
    print('WEIGHTED_25_50_25_UNCALIBRATED_DIAGNOSTIC')
    pprint({k:round(v,6) for k,v in totals.items()})
    assert abs(totals['normalization']-1)<1e-9
    assert abs(totals['p_over_5_5']+totals['p_under_5_5']-1)<1e-9
    assert abs(totals['p_motor_minus_1_5']+totals['p_liberec_plus_1_5']-1)<1e-9
