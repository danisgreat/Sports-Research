#!/usr/bin/env python3
"""Chat-only, unvalidated deterministic diagnostic. Not an authorised repository model."""
import numpy as np
from scipy.special import ndtr
# Dated exact KBL pre-event results manually transcribed from Magicorb Score team histories.
# Each tuple: date, opponent, team points, opponent points, home?
DB=[('2026-11-08','Seoul SK',65,81,False),('2026-11-07','Seoul Samsung',84,76,True),('2026-11-01','Changwon LG',104,98,False),('2026-10-31','Busan KCC',74,90,False),('2026-10-28','Daegu KOGAS',90,95,False),('2026-10-25','Anyang',95,93,False),('2026-10-23','Suwon KT',102,95,False),('2026-10-19','Daegu KOGAS',104,78,True),('2026-10-17','Seoul Samsung',92,95,True),('2026-10-12','Ulsan Mobis',89,99,False),('2026-10-10','Busan KCC',85,79,False),('2026-10-08','Changwon LG',92,96,True),('2026-10-04','Goyang Sono',95,86,True)]
KT=[('2026-11-09','Seoul Samsung',78,85,False),('2026-11-07','Daegu KOGAS',92,81,True),('2026-11-01','Goyang Sono',103,96,False),('2026-10-31','Anyang',92,90,False),('2026-10-25','Seoul SK',79,90,False),('2026-10-23','Wonju DB',95,102,True),('2026-10-18','Ulsan Mobis',80,96,True),('2026-10-17','Anyang',69,89,False),('2026-10-14','Daegu KOGAS',69,82,False),('2026-10-11','Busan KCC',87,81,False),('2026-10-09','Goyang Sono',88,79,True),('2026-10-06','Changwon LG',97,72,True),('2026-10-04','Seoul Samsung',76,81,True)]

def stats(rows,n):
    a=np.asarray([(r[2],r[3]) for r in rows[:n]],float)
    return {'n':len(a),'PF':round(float(a[:,0].mean()),3),'PA':round(float(a[:,1].mean()),3),'total':round(float(a.sum(axis=1).mean()),3),'margin':round(float((a[:,0]-a[:,1]).mean()),3),'over179.5':int(sum((a.sum(axis=1)>179.5)))}
print('DB', {n:stats(DB,n) for n in (5,10,13)})
print('KT', {n:stats(KT,n) for n in (5,10,13)})
# Scenario centres: unverified judgemental inputs; base cross from season data
# (Wonju PF90.1 + KT PA86.5)/2=88.3, KT (85.0 + Wonju PA89.3)/2=87.15
# base includes a hypothetical home / roster split adjustment of ~(+2,-2) not effect-table-estimated.
scenarios=[('low',0.25,84.0,82.0),('base',0.50,90.3,85.2),('high',0.25,98.0,90.0)]
t_sd=18.0; m_sd=14.2
s=np.arange(25,156,dtype=float)
a,b=np.meshgrid(s,s,indexing='ij')
T=a+b; M=a-b
res=[]
for name,w,mu_a,mu_b in scenarios:
    p=np.exp(-.5*((T-(mu_a+mu_b))/t_sd)**2-.5*((M-(mu_a-mu_b))/m_sd)**2)
    p/=p.sum()
    tied=(M==0); mass_tie=p[tied].sum()
    # 5m OT is added to regulation ties, 20 assumed points and 2-point margin
    u=float(p[(~tied)&(T<=179)].sum()+p[tied & ((T+20)<=179)].sum())
    v=1-u
    db=float(p[(~tied)&(M>=6)].sum()) # OT regulation tie: cannot cover -5.5
    kt=1-db
    winDB=float(p[M>0].sum()+.5*mass_tie)
    expDB=float((p*a).sum()+.5*mass_tie*20)
    expKT=float((p*b).sum()+.5*mass_tie*20)
    jointloss=float(p[(M>=6)&(T>=180)&(~tied)].sum()) # Under and KT+5.5 both lose
    res.append(dict(name=name,w=w,db_minus5_5=db,kt_plus5_5=kt,under179_5=u,over179_5=v,db_win=winDB,expDB=expDB,expKT=expKT,total=expDB+expKT,tie=mass_tie,jointloss=jointloss))
for x in res: print('SCENARIO', x)
agg={k:sum(z[k]*z['w'] for z in res) for k in ('db_minus5_5','kt_plus5_5','under179_5','over179_5','db_win','expDB','expKT','total','tie','jointloss')}
print('WEIGHTED',agg)
print('METHODOLOGY','2D Gaussian grid in regulation total and margin, independent coordinates by assumption; 5min OT ties +20 pts, split +11/+9; no qualified distribution or fitted opponent-adjusted efficiency model')
