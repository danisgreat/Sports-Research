"""Illustrative deterministic game/set/match model for the Tirante-Shevchenko Stockholm ATP 250 contracts.
No market inputs; not a calibrated model or repository release.
"""
from functools import lru_cache
from collections import defaultdict


def hold_from_point(p):
    q=1-p
    return p**4*(1+4*q+10*q*q)+20*p**3*q**3 * (p*p/(p*p+q*q))

@lru_cache(None)
def tiebreak_chance(i,j,first,pA,pB):
    if (i>=7 or j>=7) and abs(i-j)>=2:
        return float(i>j)
    n=i+j
    if i==j and i>=6:
        # At n>=12, next two serves are from opposing players; first-order invariant.
        w=pA*(1-pB); l=(1-pA)*pB
        return w/(w+l)
    srv=first if n==0 or ((n-1)//2)%2==1 else 1-first
    # Verify first,receiver,receiver,first,first,...
    pa=pA if srv==0 else 1-pB
    return pa*tiebreak_chance(i+1,j,first,pA,pB)+(1-pa)*tiebreak_chance(i,j+1,first,pA,pB)


def set_distribution(initial_server,pA,pB):
    hA=hold_from_point(pA);hB=hold_from_point(pB)
    @lru_cache(None)
    def go(a,b):
        res=defaultdict(float)
        total=a+b
        current=initial_server if total%2==0 else 1-initial_server
        if (a>=6 or b>=6) and abs(a-b)>=2:
            res[(int(a>b),a,b,current)]=1.
        elif a==b==6:
            ptb=tiebreak_chance(0,0,current,pA,pB)
            ns=1-current
            res[(1,7,6,ns)] = ptb
            res[(0,6,7,ns)] = 1-ptb
        else:
            gameA=hA if current==0 else 1-hB
            for (w,ga,gb,ns),prob in go(a+1,b).items():res[(w,ga,gb,ns)]+=gameA*prob
            for (w,ga,gb,ns),prob in go(a,b+1).items():res[(w,ga,gb,ns)]+=(1-gameA)*prob
        return dict(res)
    return go(0,0)


def match_distribution(pA,pB):
    sets={i:set_distribution(i,pA,pB) for i in (0,1)}
    result=defaultdict(float)
    def explore(sa,sb,ga,gb,first,weight,setsPlayed):
        if sa>=2 or sb>=2:
            result[(int(sa>sb),ga,gb,setsPlayed)] +=weight
            return
        for (wa,oa,ob,nextServer),p in sets[first].items():
            explore(sa+wa,sb+1-wa,ga+oa,gb+ob,nextServer,weight*p,setsPlayed+1)
    explore(0,0,0,0,0,.5,0)
    explore(0,0,0,0,1,.5,0)
    Z=sum(result.values())
    assert abs(Z-1.)<1e-8,Z
    return result


def summarize(dist):
    return dict(
        pAwin=sum(p for (w,a,b,ss),p in dist.items() if w),
        pAplus05=sum(p for (w,a,b,ss),p in dist.items() if a>=b),
        pBminus05=sum(p for (w,a,b,ss),p in dist.items() if b>a),
        pUnder235=sum(p for (w,a,b,ss),p in dist.items() if a+b<=23),
        pOver235=sum(p for (w,a,b,ss),p in dist.items() if a+b>=24),
        p3sets=sum(p for (w,a,b,ss),p in dist.items() if ss==3),
        expectedA=sum(a*p for (w,a,b,ss),p in dist.items()),
        expectedB=sum(b*p for (w,a,b,ss),p in dist.items()),
        expectedSets=sum(ss*p for (w,a,b,ss),p in dist.items()),
        pBothLossAUnder=sum(p for (w,a,b,ss),p in dist.items() if b>a and a+b>=24),
    )

if __name__=='__main__':
    # Hypothetical scenarios. NO empirical estimate of serve points from the 2026 match data.
    # A=Tirante, B=Shevchenko. Mixture weights frozen at 0.25/0.50/0.25.
    # 2026-11-09 published hard-court Elo: A 1669.4, B 1552.3; benchmarking only.
    cases=[('shevchenko_current_form',0.654,0.643,0.25),
           ('hard_elo_anchor',0.671,0.634,0.50),
           ('tirante_rest_edge',0.681,0.628,0.25)]
    ensemble=defaultdict(float)
    for tag,pA,pB,weight in cases:
        d=match_distribution(pA,pB)
        for k,prob in d.items(): ensemble[k]+=weight*prob
        print(tag, 'serve-point probabilities',pA,pB,'weight',weight,'hold',round(hold_from_point(pA),5),round(hold_from_point(pB),5))
        print({k:round(v,6) for k,v in summarize(d).items()})
    print('mixture', {k:round(v,6) for k,v in summarize(ensemble).items()})
    print('sum',sum(ensemble.values()),'states',len(ensemble))
    elo=1/(1+10**((1552.3-1669.4)/400))
    print('dated_hard_elo_win_reference_Tirante',round(elo,6))
    print('note: deterministic sensitivity diagnostic, not validated p_card; no Monte Carlo and no GitHub release')
