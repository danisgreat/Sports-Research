#!/usr/bin/env python3
"""G0004 illustrative WNBL score grid -- NOT a qualified/frozen forecast.
Deterministic bivariate normal integer regulation-score grid with an explicit OT tie branch.
Based on public pregame score averages, no bookmaker information or fitted WNBL calibration.
"""
import numpy as np
from scipy.stats import multivariate_normal

sd_total = 18.5          # FIBA40 family prior 16.82 widened 10% (approx), not WNBL fitted
sd_margin = 14.0         # FIBA40 family prior 12.76 widened 10% (approx), not WNBL fitted
score_var = (sd_total**2 + sd_margin**2)/4
score_cov = (sd_total**2 - sd_margin**2)/4
cov = [[score_var, score_cov],[score_cov,score_var]]
scenarios = [
  ('low-tempo',0.25,74.0,80.0),
  ('venue-cross-base',0.50,(69.6666666667+90.5)/2,(88.0+75.3333333333)/2),
  ('high-tempo',0.25,85.0,90.0),
]
pts=np.arange(25,151,dtype=np.int32)
gx,px=np.meshgrid(pts,pts,indexing='ij')
mask_tie=(gx==px)
final=[]
for name,w,geelong,perth in scenarios:
  p=multivariate_normal.pdf(np.stack([gx,px],axis=-1),mean=[geelong,perth],cov=cov)
  p=p/p.sum()
  probs={k:0. for k in ['geelong_plus_6_5','perth_minus_6_5','under_163_5','over_163_5','geelong_win','perth_win','both_fail','mean_geelong','mean_perth','mean_total','mean_margin_perth','ot_mass']}
  def deposit(a,b,mass):
    probs['geelong_plus_6_5']+=float(np.sum(mass*(a+6.5>b)))
    probs['perth_minus_6_5']+=float(np.sum(mass*(b-a>6.5)))
    probs['under_163_5']+=float(np.sum(mass*(a+b<=163)))
    probs['over_163_5']+=float(np.sum(mass*(a+b>=164)))
    probs['geelong_win']+=float(np.sum(mass*(a>b)))
    probs['perth_win']+=float(np.sum(mass*(b>a)))
    probs['both_fail']+=float(np.sum(mass*(b-a>=7)*(a+b>=164)))
    probs['mean_geelong']+=float(np.sum(mass*a)); probs['mean_perth']+=float(np.sum(mass*b))
    probs['mean_total']+=float(np.sum(mass*(a+b))); probs['mean_margin_perth']+=float(np.sum(mass*(b-a)))
  deposit(gx,px,np.where(mask_tie,0,p))
  # Only tied regulation states go to 5-minute OT. Each case adds 20 total points,
  # with ±(2,6,10) point OT margins at weights (.6,.3,.1), equal win splits.
  diag_x=pts.astype(float); diag_p=np.diag(p)
  for dg,dp,weight in [(11,9,.30),(9,11,.30),(13,7,.15),(7,13,.15),(15,5,.05),(5,15,.05)]:
    deposit(diag_x+dg,diag_x+dp,diag_p*weight)
  probs['ot_mass']=float(diag_p.sum())
  assert abs(probs['geelong_plus_6_5']+probs['perth_minus_6_5']-1)<1e-10
  assert abs(probs['under_163_5']+probs['over_163_5']-1)<1e-10
  assert abs(probs['geelong_win']+probs['perth_win']-1)<1e-10
  final.append((name,w,probs))
  print(name, 'weight',w, 'means',geelong,perth, {k:round(v,5) for k,v in probs.items()})
combined={k:sum(w*p[k] for _,w,p in final) for k in final[0][2]}
print('\nMIXTURE', {k:round(v,6) for k,v in combined.items()})
print('FAMILY_PRIOR_SDS',sd_total,sd_margin,'cov',score_cov,'regulation_tie_modelled_in_each_scenario')
